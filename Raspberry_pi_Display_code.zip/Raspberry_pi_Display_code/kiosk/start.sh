#!/bin/bash

# Wait briefly for the desktop
sleep 2

# Hide mouse cursor
unclutter -idle 0 -root &

# Create Chromium profile
mkdir -p /home/pi/.config/chromium-kiosk

# Wait until network is available
until ping -c1 8.8.8.8 >/dev/null 2>&1
do
    sleep 1
done

while true
do
    chromium \
        --kiosk \
        --start-fullscreen \
        --incognito \
        --user-data-dir=/home/pi/.config/chromium-kiosk \
        --password-store=basic \
        --no-first-run \
        --no-default-browser-check \
        --disable-sync \
        --disable-session-crashed-bubble \
        --disable-infobars \
        --disable-restore-session-state \
        --disable-features=PasswordManagerEnabled,TranslateUI \
        --disable-background-networking \
        --disable-component-update \
        --disable-default-apps \
        --disable-popup-blocking \
        --disable-extensions \
        --disable-gpu \
        --overscroll-history-navigation=0 \
        https://rfc-towards-sustainability.netlify.app/

    sleep 2
done
