# RFC Environmental Dashboard — Firebase Production Package

## Architecture

ESP32 sensors
  -> local acquisition
  -> Firebase Authentication
  -> Firebase Realtime Database
  -> Firebase Hosting
  -> public read-only dashboard

The local ESP32 dashboard continues to work independently.

## 1. Firebase Console

Project:
RFC Environmental Dashboard

Enable:
1. Realtime Database
2. Authentication -> Sign-in method -> Email/Password
3. Create one dedicated device user for the ESP32.

Do NOT use your personal Firebase account as the device account.

Example device account:
YOUR_DEVICE_EMAIL
YOUR_DEVICE_PASSWORD

After creating the account, keep the email and password private.

## 2. Get the Firebase Web API key

Firebase Console:
Project settings -> General -> Your apps -> Web app

Copy the Web API key.

The API key identifies the Firebase project. Database writes are still protected by Authentication and Security Rules.

## 3. Get the Realtime Database URL

Firebase Console:
Realtime Database -> Data

Copy the database URL.

Typical forms are:
https://DATABASE_NAME.firebaseio.com
or
https://DATABASE_NAME.REGION.firebasedatabase.app

Put that exact URL in:
firmware/ESP32_Environmental_Dashboard_FIREBASE.ino
and
firebase-dashboard/index.html

## 4. Configure the firmware

Edit only these placeholders:

YOUR_WIFI_SSID
YOUR_WIFI_PASSWORD
YOUR_FIREBASE_WEB_API_KEY
YOUR_DATABASE_NAME.firebaseio.com
YOUR_DEVICE_EMAIL
YOUR_DEVICE_PASSWORD

Keep the device ID:
rfc-environment-001

The firmware stores the Firebase refresh token in ESP32 NVS after the first successful sign-in. It does not store the short-lived ID token permanently.

## 5. Arduino libraries

Keep your existing sensor libraries:

- Adafruit Sensor
- Adafruit SHT31
- Adafruit BME680
- Adafruit BMP280
- Adafruit VEML6075
- BH1750
- RTClib

Additional libraries required by the Firebase firmware:

- Preferences (included with ESP32 core)
- HTTPClient (included with ESP32 core)
- WiFiClientSecure (included with ESP32 core)

No Firebase third-party Arduino library is required. The firmware uses Firebase's HTTPS REST APIs.

## 6. Important BMP280 fix

Do NOT declare:

constexpr uint8_t BMP280_ADDRESS = 0x76;

The Adafruit BMP280 library already defines BMP280_ADDRESS.

This package uses:

constexpr uint8_t BMP280_I2C_ADDRESS = 0x76;

and correctly records the selected address using BMP280_I2C_ADDRESS.

## 7. Copy the Ramoji image

Copy your existing:

data/rfc1.jpeg

to:

firebase-dashboard/rfc1.jpeg

The Firebase dashboard expects that exact filename.

## 8. Install Firebase CLI

Open Windows Terminal / Command Prompt:

npm install -g firebase-tools

Then:

firebase login

## 9. Deploy

Open terminal in this folder:

firebase use rfc-environment-dashboard

If the project is not configured yet:

firebase init

Select:
- Realtime Database
- Hosting

Choose the existing project:
RFC Environmental Dashboard

For Hosting public directory use:
firebase-dashboard

Do NOT overwrite index.html if asked.

Then deploy:

firebase deploy --only database,hosting

## 10. Public dashboard

After deployment Firebase will print the Hosting URL.

Anyone with that URL can view the dashboard.

The browser has read-only access.

The browser never receives the ESP32 Firebase password.

## 11. Security

Production rules:
- public READ for the environmental dashboard
- WRITE only for the authenticated device account
- delete is blocked
- no public write access

Never use:

".read": true,
".write": true

for production.

## 12. Expected Firebase data

devices/
  rfc-environment-001/
    latest/
      updatedAt
      slides
      diagnostics

The dashboard reads only:
devices/rfc-environment-001/latest

## 13. ESP32 operation

The firmware:
- keeps reading sensors every 5 seconds
- keeps the local web server running
- publishes the dashboard snapshot every 60 seconds
- refreshes Firebase authentication automatically
- reconnects Wi-Fi automatically
- continues sensor operation when Firebase is unavailable
- does not reboot just because Firebase is offline

## 14. Commissioning

For the first installation keep:

DASHBOARD_UPDATE_INTERVAL_MINUTES = 1

After the complete system is verified, change it to:

DASHBOARD_UPDATE_INTERVAL_MINUTES = 60

The sensor acquisition remains 5 seconds.

## 15. Serial Monitor

Use:
115200 baud

Expected Firebase messages:

[Firebase] Signing in...
[Firebase] Authenticated. UID=...
[Firebase] Upload OK: ... bytes

If Firebase is unavailable, the local sensor system should continue operating.

## 16. Important

The uploaded source previously contained real Wi-Fi credentials. This final package replaces them with placeholders. If those credentials are still active, change the Wi-Fi password before production deployment.
