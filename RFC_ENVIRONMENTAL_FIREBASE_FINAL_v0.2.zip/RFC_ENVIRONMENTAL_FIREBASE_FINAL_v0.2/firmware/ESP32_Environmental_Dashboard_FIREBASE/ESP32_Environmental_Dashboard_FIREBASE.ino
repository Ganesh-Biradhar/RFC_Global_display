/*
  ============================================================================
  RFC ENVIRONMENTAL DASHBOARD
  ESP32 DEV MODULE
  PRODUCTION / COMMISSIONING FIRMWARE
  ============================================================================

  I2C:
    SDA = GPIO21
    SCL = GPIO22

    SHT31     = 0x44
    BME680    = 0x77
    BMP280    = 0x76
    BH1750    = 0x23
    VEML6075  = 0x10
    DS3231    = 0x68

  UART:
    PMS7003:
      ESP32 RX = GPIO16
      ESP32 TX = GPIO17
      9600 baud

    MH-Z19C:
      ESP32 RX = GPIO27
      ESP32 TX = GPIO26
      9600 baud

  ADC:
    TDS       = GPIO34
    pH        = GPIO35
    Rain      = GPIO33
    MAX9814   = GPIO32

  WEB:
    /                 -> LittleFS /index.html
    /api/sensors      -> dashboard JSON
    /api/data         -> compatibility alias
    /api/health       -> health/diagnostics JSON
    /api/refresh      -> forced acquisition + publish

  IMPORTANT:
    - ESP32 GPIO is NOT 5V tolerant.
    - All devices must share GND.
    - I2C devices require correct SDA/SCL wiring.
    - BME680/BMP280 address is automatically detected.
    - Analog sensors require physical calibration.
    - PMS7003 and MH-Z19C require crossed UART connections.
    - /index.html must exist in LittleFS.

  COMMISSIONING:
    DASHBOARD_UPDATE_INTERVAL_MINUTES = 1

  PRODUCTION:
    Change to 60 after complete commissioning.

  ============================================================================

  REQUIRED LIBRARIES:
    Adafruit Sensor
    Adafruit SHT31
    Adafruit BME680
    Adafruit BMP280
    Adafruit VEML6075
    BH1750
    RTClib

  ============================================================================ */

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <math.h>

#include <Adafruit_Sensor.h>
#include <Adafruit_SHT31.h>
#include <Adafruit_BME680.h>
#include <Adafruit_BMP280.h>
#include <Adafruit_VEML6075.h>
#include <BH1750.h>
#include <RTClib.h>
#include "time.h"

// ============================================================================
// WIFI
// ============================================================================

const char* WIFI_SSID     = "TDG_HYD";
const char* WIFI_PASSWORD = "9848023755";

// ============================================================================
// NTP / RTC
// ============================================================================

const char* NTP_SERVER = "pool.ntp.org";

constexpr long GMT_OFFSET_SECONDS = 5L * 3600L + 30L * 60L;
constexpr int DAYLIGHT_OFFSET_SECONDS = 0;

constexpr uint32_t WIFI_TIMEOUT_MS = 10000UL;
constexpr uint32_t WIFI_RETRY_INTERVAL_MS = 15000UL;
constexpr uint32_t NTP_RESYNC_INTERVAL_MS = 3600000UL;

// ============================================================================
// DASHBOARD / ACQUISITION
// ============================================================================

constexpr uint32_t DASHBOARD_UPDATE_INTERVAL_MINUTES = 1UL;

// Physical sensor acquisition interval.
constexpr uint32_t SENSOR_ACQUISITION_INTERVAL_SECONDS = 5UL;

// ============================================================================
// FIREBASE
// ============================================================================
//
// Firebase Realtime Database is used through the official REST API.
// Authentication uses Firebase Email/Password Auth.
// The browser dashboard has PUBLIC READ access only.
// The ESP32 device account is the only intended writer.
//
// Before flashing:
//   1. Replace the Firebase placeholders below.
//   2. Enable Email/Password authentication.
//   3. Create a dedicated Firebase user for this ESP32.
//   4. Create Realtime Database rules from database.rules.json.
//
// IMPORTANT:
//   The Firebase Web API key is not a database password. Firebase documents
//   these keys as identifiers for Firebase services. Database access is still
//   controlled by Authentication + Realtime Database Security Rules.
//

constexpr bool FIREBASE_ENABLED = true;

const char* FIREBASE_API_KEY =
  "AIzaSyDPyojhuYs6UjanLFD218PpMOD5CHK4g3Q";

const char* FIREBASE_DATABASE_URL =
  "https://rfc-environmental-dashboard-default-rtdb.asia-southeast1.firebasedatabase.app";

const char* FIREBASE_DEVICE_EMAIL =
  "rfc-esp32-001@gmail.com";

const char* FIREBASE_DEVICE_PASSWORD =
  "GYAM_TECH_rfc_esp32_001";

const char* FIREBASE_DEVICE_ID =
  "rfc-environment-001";

constexpr uint32_t FIREBASE_UPLOAD_INTERVAL_MS =
  60000UL;

constexpr uint32_t FIREBASE_HTTP_TIMEOUT_MS =
  12000UL;

constexpr uint32_t FIREBASE_TOKEN_REFRESH_MARGIN_MS =
  60000UL;

// Google Trust Services GTS Root R1.
// Valid through 2036 according to Google Trust Services.
static const char FIREBASE_GTS_ROOT_R1[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
MIIFVzCCAz+gAwIBAgINAgPlk28xsBNJiGuiFzANBgkqhkiG9w0BAQwFADBHMQsw
CQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExMQzEU
MBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMTYwNjIyMDAwMDAwWhcNMzYwNjIyMDAw
MDAwWjBHMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZp
Y2VzIExMQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwggIiMA0GCSqGSIb3DQEBAQUA
A4ICDwAwggIKAoICAQC2EQKLHuOhd5s73L+UPreVp0A8of2C+X0yBoJx9vaMf/vo
27xqLpeXo4xL+Sv2sfnOhB2x+cWX3u+58qPpvBKJXqeqUqv4IyfLpLGcY9vXmX7w
Cl7raKb0xlpHDU0QM+NOsROjyBhsS+z8CZDfnWQpJSMHobTSPS5g4M/SCYe7zUjw
TcLCeoiKu7rPWRnWr4+wB7CeMfGCwcDfLqZtbBkOtdh+JhpFAz2weaSUKK0Pfybl
qAj+lug8aJRT7oM6iCsVlgmy4HqMLnXWnOunVmSPlk9orj2XwoSPwLxAwAtcvfaH
szVsrBhQf4TgTM2S0yDpM7xSma8ytSmzJSq0SPly4cpk9+aCEI3oncKKiPo4Zor8
Y/kB+Xj9e1x3+naH+uzfsQ55lVe0vSbv1gHR6xYKu44LtcXFilWr06zqkUspzBmk
MiVOKvFlRNACzqrOSbTqn3yDsEB750Orp2yjj32JgfpMpf/VjsPOS+C12LOORc92
wO1AK/1TD7Cn1TsNsYqiA94xrcx36m97PtbfkSIS5r762DL8EGMUUXLeXdYWk70p
aDPvOmbsB4om3xPXV2V4J95eSRQAogB/mqghtqmxlbCluQ0WEdrHbEg8QOB+DVrN
VjzRlwW5y0vtOUucxD/SVRNuJLDWcfr0wbrM7Rv1/oFB2ACYPTrIrnqYNxgFlQID
AQABo0IwQDAOBgNVHQ8BAf8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4E
FgQU5K8rJnEaK0gnhS9SZizv8IkTcT4wDQYJKoZIhvcNAQEMBQADggIBAJ+qQibb
C5u+/x6Wki4+omVKapi6Ist9wTrYggoGxval3sBOh2Z5ofmmWJyq+bXmYOfg6LEe
QkEzCzc9zolwFcq1JKjPa7XSQCGYzyI0zzvFIoTgxQ6KfF2I5DUkzps+GlQebtuy
h6f88/qBVRRiClmpIgUxPoLW7ttXNLwzldMXG+gnoot7TiYaelpkttGsN/H9oPM4
7HLwEXWdyzRSjeZ2axfG34arJ45JK3VmgRAhpuo+9K4l/3wV3s6MJT/KYnAK9y8J
ZgfIPxz88NtFMN9iiMG1D53Dn0reWVlHxYciNuaCp+0KueIHoI17eko8cdLiA6Ef
MgfdG+RCzgwARWGAtQsgWSl4vflVy2PFPEz0tv/bal8xa5meLMFrUKTX5hgUvYU/
Z6tGn6D/Qqc6f1zLXbBwHSs09dR2CQzreExZBfMzQsNhFRAbd03OIozUhfJFfbdT
6u9AWpQKXCBfTkBdYiJ23//OYb2MI3jSNwLgjt7RETeJ9r/tSQdirpLsQBqvFAnZ
0E6yove+7u7Y/9waLd64NnHi/Hm3lCXRSHNboTXns5lndcEZOitHTtNCjv0xyBZm
2tIMPNuzjsmhDYAPexZ3FL//2wmUspzO8IFgV6dtxQ/PeEMMA3KgqlbbC1j+Qa3bb
bP6MvPJwNQzcmRk13NfIRmPVnGuV/u3gm3c
-----END CERTIFICATE-----
)EOF";

Preferences firebasePreferences;

String firebaseIdToken;
String firebaseRefreshToken;
String firebaseUid;

uint32_t firebaseTokenExpiresAtMs = 0;
uint32_t lastFirebaseUploadMs = 0;

bool firebaseAuthenticated = false;


// ============================================================================
// ANALOG CALIBRATION
// ============================================================================

constexpr float TDS_CALIBRATION_FACTOR = 1.00f;
constexpr float HARDNESS_TDS_FACTOR = 0.50f;

// pH = 7 + ((V - PH_VOLTAGE_AT_PH7) / PH_SLOPE_V_PER_PH)
constexpr float PH_VOLTAGE_AT_PH7 = 2.50f;
constexpr float PH_SLOPE_V_PER_PH = -0.18f;

// Rain calibration.
// MUST be changed after measuring the actual board.
constexpr int RAIN_ADC_DRY = 4095;
constexpr int RAIN_ADC_WET = 1200;

// ============================================================================
// GPIO
// ============================================================================

constexpr int I2C_SDA_PIN = 21;
constexpr int I2C_SCL_PIN = 22;

constexpr int PMS7003_RX_PIN = 16;
constexpr int PMS7003_TX_PIN = 17;

constexpr int MHZ19C_RX_PIN = 27;
constexpr int MHZ19C_TX_PIN = 26;

constexpr int TDS_ADC_PIN   = 34;
constexpr int PH_ADC_PIN    = 35;
constexpr int RAIN_ADC_PIN  = 33;
constexpr int SOUND_ADC_PIN = 32;

// ============================================================================
// I2C ADDRESSES
// ============================================================================

constexpr uint8_t SHT31_ADDRESS = 0x44;

constexpr uint8_t BME680_ADDRESS = 0x77;

constexpr uint8_t BMP280_I2C_ADDRESS = 0x76;

constexpr uint8_t BH1750_ADDRESS = 0x23;
constexpr uint8_t VEML6075_ADDRESS = 0x10;
constexpr uint8_t DS3231_ADDRESS = 0x68;

// ============================================================================
// OBJECTS
// ============================================================================

WebServer server(80);

Adafruit_SHT31 sht31;

Adafruit_BME680 bme680(&Wire);

Adafruit_BMP280 bmp280(&Wire);

Adafruit_VEML6075 veml6075;

BH1750 bh1750;

RTC_DS3231 rtc;

HardwareSerial pmsSerial(2);
HardwareSerial mhzSerial(1);

// ============================================================================
// SENSOR HEALTH
// ============================================================================

struct SensorHealth {

  bool sht31 = false;

  bool bme680 = false;
  uint8_t bme680Address = 0;

  bool bmp280 = false;
  uint8_t bmp280Address = 0;

  bool bh1750 = false;

  bool veml6075 = false;

  bool ds3231 = false;
  bool rtcValid = false;

  bool pms7003 = false;
  bool mhz19c = false;

  bool tds = false;
  bool ph = false;
  bool rain = false;
  bool sound = false;
};

SensorHealth health;

// ============================================================================
// SENSOR DATA
// ============================================================================

struct SensorData {

  float temperatureC = NAN;
  float humidityPct = NAN;

  float pressureHpa = NAN;
  float gasKOhm = NAN;

  uint16_t pm1 = 0;
  uint16_t pm25 = 0;
  uint16_t pm10 = 0;

  bool pmValid = false;

  int co2ppm = -1;
  bool co2Valid = false;

  float lux = NAN;
  float uvIndex = NAN;

  int tdsRaw = -1;
  float tdsVoltage = NAN;
  float tdsPpm = NAN;

  // Estimated total hardness as mg/L as CaCO3.
  // This is calculated from TDS and is NOT a direct measurement.
  float estimatedHardnessMgL = NAN;

  int phRaw = -1;
  float phVoltage = NAN;
  float ph = NAN;

  int rainRaw = -1;
  float rainWetPct = NAN;

  int soundPeakToPeak = -1;
  float soundRelativePct = NAN;

  String rtcIso = "";
  String rtcDisplay = "";

  int aqi = -1;
  String aqiStatus = "UNAVAILABLE";

  uint32_t sampleMillis = 0;
};

SensorData workingData;
SensorData publishedData;

bool publishedReady = false;

// ============================================================================
// TIMERS
// ============================================================================

uint32_t lastAcquisitionMs = 0;
uint32_t lastPublishMs = 0;

uint32_t lastWifiRetryMs = 0;
uint32_t lastNtpSyncMs = 0;

bool wifiConnected = false;
bool rtcNtpSynchronized = false;

// ============================================================================
// HELPERS
// ============================================================================

static bool validFloat(float value) {

  return !isnan(value) && !isinf(value);
}

// ----------------------------------------------------------------------------

static String jsonEscape(const String& value) {

  String out;

  out.reserve(value.length() + 8);

  for (size_t i = 0; i < value.length(); ++i) {

    const char c = value[i];

    if (c == '\\') {
      out += "\\\\";
    }
    else if (c == '"') {
      out += "\\\"";
    }
    else if (c == '\n') {
      out += "\\n";
    }
    else if (c == '\r') {
      out += "\\r";
    }
    else if ((uint8_t)c >= 0x20) {
      out += c;
    }
  }

  return out;
}

// ----------------------------------------------------------------------------

static String boolJson(bool value) {

  return value ? "true" : "false";
}

// ----------------------------------------------------------------------------

static String makeRow(
  const String& label,
  const String& value
) {
  String row;

  row.reserve(
    label.length() +
    value.length() +
    32
  );

  row += "{\"label\":\"";
  row += jsonEscape(label);
  row += "\",\"value\":\"";
  row += jsonEscape(value);
  row += "\"}";

  return row;
}


// ============================================================================
// FIREBASE REST / AUTHENTICATION
// ============================================================================

static String buildDashboardJson();


static bool jsonExtractString(
  const String& json,
  const char* key,
  String& value
) {
  // Find the key name.
  const String keyNeedle =
    String("\"") +
    key +
    "\"";

  int pos =
    json.indexOf(
      keyNeedle
    );

  if (pos < 0) {
    return false;
  }

  // Move past the key.
  pos += keyNeedle.length();

  // Skip whitespace.
  while (
    pos < json.length() &&
    isspace(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    pos++;
  }

  // Expect ':'.
  if (
    pos >= json.length() ||
    json[pos] != ':'
  ) {
    return false;
  }

  pos++;

  // Skip whitespace after ':'.
  while (
    pos < json.length() &&
    isspace(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    pos++;
  }

  // Expect opening quote.
  if (
    pos >= json.length() ||
    json[pos] != '"'
  ) {
    return false;
  }

  pos++;

  String result;

  result.reserve(
    256
  );

  bool escaped = false;

  while (
    pos < json.length()
  ) {

    const char c =
      json[pos];

    if (escaped) {

      switch (c) {

        case '"':
          result += '"';
          break;

        case '\\':
          result += '\\';
          break;

        case '/':
          result += '/';
          break;

        case 'b':
          result += '\b';
          break;

        case 'f':
          result += '\f';
          break;

        case 'n':
          result += '\n';
          break;

        case 'r':
          result += '\r';
          break;

        case 't':
          result += '\t';
          break;

        default:
          // Preserve unknown escape.
          result += c;
          break;
      }

      escaped = false;
      pos++;

      continue;
    }

    if (
      c == '\\'
    ) {
      escaped = true;
      pos++;

      continue;
    }

    if (
      c == '"'
    ) {
      value =
        result;

      return true;
    }

    result += c;

    pos++;
  }

  return false;
}
// ----------------------------------------------------------------------------

static int jsonExtractInt(
  const String& json,
  const char* key,
  int defaultValue
) {
  const String keyNeedle =
    String("\"") +
    key +
    "\"";

  int pos =
    json.indexOf(
      keyNeedle
    );

  if (pos < 0) {
    return defaultValue;
  }

  pos += keyNeedle.length();

  // Skip whitespace.
  while (
    pos < json.length() &&
    isspace(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    pos++;
  }

  // Expect ':'.
  if (
    pos >= json.length() ||
    json[pos] != ':'
  ) {
    return defaultValue;
  }

  pos++;

  // Skip whitespace.
  while (
    pos < json.length() &&
    isspace(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    pos++;
  }

  // Optional quoted number.
  bool quoted = false;

  if (
    pos < json.length() &&
    json[pos] == '"'
  ) {
    quoted = true;
    pos++;
  }

  int sign = 1;

  if (
    pos < json.length() &&
    json[pos] == '-'
  ) {
    sign = -1;
    pos++;
  }

  int result = 0;

  bool foundDigit = false;

  while (
    pos < json.length() &&
    isDigit(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    result =
      result * 10 +
      (
        json[pos] - '0'
      );

    foundDigit = true;

    pos++;
  }

  if (!foundDigit) {
    return defaultValue;
  }

  if (quoted) {
    if (
      pos >= json.length() ||
      json[pos] != '"'
    ) {
      return defaultValue;
    }
  }

  return result * sign;
}

// ----------------------------------------------------------------------------

static String firebaseDatabaseUrl() {
  String url = FIREBASE_DATABASE_URL;

  while (
    url.endsWith("/")
  ) {
    url.remove(
      url.length() - 1
    );
  }

  return url;
}

// ----------------------------------------------------------------------------

static bool firebaseHttpPost(
  const String& url,
  const String& payload,
  String& response
) {
  WiFiClientSecure client;

  //client.setCACert(
  //  FIREBASE_GTS_ROOT_R1
  //);

  // TEMPORARY DIAGNOSTIC ONLY
  client.setInsecure();

  HTTPClient http;

  http.setConnectTimeout(
    FIREBASE_HTTP_TIMEOUT_MS
  );

  http.setTimeout(
    FIREBASE_HTTP_TIMEOUT_MS
  );

  if (
    !http.begin(
      client,
      url
    )
  ) {
    Serial.println(
      "[Firebase] HTTPS begin failed."
    );

    return false;
  }

  http.addHeader(
    "Content-Type",
    "application/json"
  );

  const int code =
    http.POST(
      payload
    );

  response =
    http.getString();

  http.end();

  if (
      code < 200 ||
      code >= 300
  ) {
      Serial.printf(
        "[Firebase] POST HTTP %d\n",
        code
      );

      Serial.printf(
        "[Firebase] Error: %s\n",
        HTTPClient::errorToString(code).c_str()
      );

      if (response.length()) {
        Serial.print(
          "[Firebase] Response: "
        );

        Serial.println(
          response
        );
      }

      return false;
  }

  return true;
}

// ----------------------------------------------------------------------------

static bool firebaseHttpPostForm(
  const String& url,
  const String& payload,
  String& response
) {
  WiFiClientSecure client;

  client.setCACert(
    FIREBASE_GTS_ROOT_R1
  );

  HTTPClient http;

  http.setConnectTimeout(
    FIREBASE_HTTP_TIMEOUT_MS
  );

  http.setTimeout(
    FIREBASE_HTTP_TIMEOUT_MS
  );

  if (
    !http.begin(
      client,
      url
    )
  ) {
    Serial.println(
      "[Firebase] HTTPS begin failed."
    );

    return false;
  }

  http.addHeader(
    "Content-Type",
    "application/x-www-form-urlencoded"
  );

  const int code =
    http.POST(
      payload
    );

  response =
    http.getString();

  http.end();

  if (
    code < 200 ||
    code >= 300
  ) {
    Serial.printf(
      "[Firebase] FORM POST HTTP %d\n",
      code
    );

    Serial.printf(
      "[Firebase] FORM Error: %s\n",
      HTTPClient::errorToString(code).c_str()
    );

    if (response.length()) {
      Serial.print(
        "[Firebase] FORM Response: "
      );

      Serial.println(
        response
      );
    }

    return false;
  }

  return true;
}

// ----------------------------------------------------------------------------

static String urlEncode(
  const String& input
) {
  const char hex[] =
    "0123456789ABCDEF";

  String output;

  output.reserve(
    input.length() * 2
  );

  for (
    size_t i = 0;
    i < input.length();
    ++i
  ) {
    const uint8_t c =
      static_cast<uint8_t>(
        input[i]
      );

    if (
      (
        c >= 'a' &&
        c <= 'z'
      ) ||
      (
        c >= 'A' &&
        c <= 'Z'
      ) ||
      (
        c >= '0' &&
        c <= '9'
      ) ||
      c == '-' ||
      c == '_' ||
      c == '.' ||
      c == '~'
    ) {
      output += static_cast<char>(c);
    }
    else {
      output += '%';
      output += hex[
        (c >> 4) & 0x0F
      ];
      output += hex[
        c & 0x0F
      ];
    }
  }

  return output;
}

// ----------------------------------------------------------------------------
static void firebaseNetworkDiagnostics() {

  Serial.println();
  Serial.println(
    "[Firebase] NETWORK DIAGNOSTICS"
  );

  Serial.printf(
    "[Firebase] WiFi status : %d\n",
    WiFi.status()
  );

  Serial.printf(
    "[Firebase] RSSI        : %d dBm\n",
    WiFi.RSSI()
  );

  Serial.printf(
    "[Firebase] IP          : %s\n",
    WiFi.localIP().toString().c_str()
  );

  Serial.printf(
    "[Firebase] Gateway     : %s\n",
    WiFi.gatewayIP().toString().c_str()
  );

  Serial.printf(
    "[Firebase] DNS         : %s\n",
    WiFi.dnsIP().toString().c_str()
  );

  Serial.printf(
    "[Firebase] Free heap   : %u bytes\n",
    ESP.getFreeHeap()
  );

  Serial.println();
}

static bool testFirebaseTlsConnection() {

  Serial.println();
  Serial.println(
    "[TLS] Testing TLS connection to Google..."
  );

  WiFiClientSecure client;

  // TEMPORARY diagnostic only.
  // This bypasses certificate verification.
  client.setInsecure();

  const char* host =
    "identitytoolkit.googleapis.com";

  const uint16_t port = 443;

  const uint32_t start =
    millis();

  if (!client.connect(host, port)) {

    Serial.println(
      "[TLS] TLS connection FAILED"
    );

    Serial.printf(
      "[TLS] Time: %lu ms\n",
      static_cast<unsigned long>(
        millis() - start
      )
    );

    client.stop();

    return false;
  }

  Serial.println(
    "[TLS] TLS connection SUCCESS"
  );

  Serial.printf(
    "[TLS] Time: %lu ms\n",
    static_cast<unsigned long>(
      millis() - start
    )
  );

  client.stop();

  return true;
}

static bool firebaseSignIn() {
  if (
    !FIREBASE_ENABLED ||
    WiFi.status() != WL_CONNECTED
  ) {
    return false;
  }

  if (
    strlen(FIREBASE_API_KEY) == 0 ||
    strlen(FIREBASE_DEVICE_EMAIL) == 0 ||
    strlen(FIREBASE_DEVICE_PASSWORD) == 0
  ) {
    Serial.println(
      "[Firebase] Missing authentication configuration."
    );

    return false;
  }

  const String url =
    String(
      "https://identitytoolkit.googleapis.com/"
      "v1/accounts:signInWithPassword?key="
    ) +
    FIREBASE_API_KEY;

  String payload;

  payload.reserve(
    512
  );

  payload +=
    "{\"email\":\"";

  payload +=
    jsonEscape(
      FIREBASE_DEVICE_EMAIL
    );

  payload +=
    "\",\"password\":\"";

  payload +=
    jsonEscape(
      FIREBASE_DEVICE_PASSWORD
    );

  payload +=
    "\",\"returnSecureToken\":true}";

  String response;

  firebaseNetworkDiagnostics();

  //testFirebaseTcpConnection();

  testFirebaseTlsConnection();

  Serial.println(
    "[Firebase] Signing in..."
  );

  if (
    !firebaseHttpPost(
      url,
      payload,
      response
    )
  ) {
    firebaseAuthenticated =
      false;

    return false;
  }

  String idToken;
  String refreshToken;
  String uid;

  if (
    !jsonExtractString(
      response,
      "idToken",
      idToken
    ) ||
    !jsonExtractString(
      response,
      "refreshToken",
      refreshToken
    )
  ) {

    Serial.println(
      "[Firebase] Sign-in response did not contain tokens."
    );

    Serial.println(
      "[Firebase] FULL RESPONSE:"
    );

    Serial.println(
      response
    );

    firebaseAuthenticated =
      false;

    return false;
  }

  jsonExtractString(
    response,
    "localId",
    uid
  );

  const int expiresIn =
    jsonExtractInt(
      response,
      "expiresIn",
      3600
    );

  firebaseIdToken =
    idToken;

  firebaseRefreshToken =
    refreshToken;

  firebaseUid =
    uid;

  firebaseTokenExpiresAtMs =
    millis() +
    static_cast<uint32_t>(
      max(
        60,
        expiresIn -
        static_cast<int>(
          FIREBASE_TOKEN_REFRESH_MARGIN_MS /
          1000UL
        )
      )
    ) *
    1000UL;

  firebaseAuthenticated =
    true;

  // Store only the long-lived refresh token.
  firebasePreferences.putString(
    "refresh",
    firebaseRefreshToken
  );

  Serial.printf(
    "[Firebase] Authenticated. UID=%s\n",
    firebaseUid.c_str()
  );

  return true;
}

// ----------------------------------------------------------------------------

static bool firebaseRefreshIdToken() {
  if (
    !FIREBASE_ENABLED ||
    WiFi.status() != WL_CONNECTED ||
    firebaseRefreshToken.isEmpty()
  ) {
    return false;
  }

  const String url =
    String(
      "https://securetoken.googleapis.com/"
      "v1/token?key="
    ) +
    FIREBASE_API_KEY;

  const String payload =
    String(
      "grant_type=refresh_token&refresh_token="
    ) +
    urlEncode(
      firebaseRefreshToken
    );

  String response;

  Serial.println(
    "[Firebase] Refreshing ID token..."
  );

  if (
    !firebaseHttpPostForm(
      url,
      payload,
      response
    )
  ) {
    firebaseAuthenticated =
      false;

    return false;
  }

  String idToken;
  String refreshToken;
  String uid;

  if (
    !jsonExtractString(
      response,
      "id_token",
      idToken
    )
  ) {
    Serial.println(
      "[Firebase] Token refresh failed."
    );

    firebaseAuthenticated =
      false;

    return false;
  }

  jsonExtractString(
    response,
    "refresh_token",
    refreshToken
  );

  jsonExtractString(
    response,
    "user_id",
    uid
  );

  const int expiresIn =
    jsonExtractInt(
      response,
      "expires_in",
      3600
    );

  firebaseIdToken =
    idToken;

  if (
    refreshToken.length()
  ) {
    firebaseRefreshToken =
      refreshToken;

    firebasePreferences.putString(
      "refresh",
      firebaseRefreshToken
    );
  }

  if (
    uid.length()
  ) {
    firebaseUid =
      uid;
  }

  firebaseTokenExpiresAtMs =
    millis() +
    static_cast<uint32_t>(
      max(
        60,
        expiresIn - 60
      )
    ) *
    1000UL;

  firebaseAuthenticated =
    true;

  Serial.println(
    "[Firebase] ID token refreshed."
  );

  return true;
}

// ----------------------------------------------------------------------------

static bool firebaseEnsureAuthenticated() {
  if (
    !FIREBASE_ENABLED
  ) {
    return false;
  }

  if (
    WiFi.status() != WL_CONNECTED
  ) {
    return false;
  }

  const uint32_t now =
    millis();

  if (
    firebaseAuthenticated &&
    static_cast<int32_t>(
      now -
      firebaseTokenExpiresAtMs
    ) < 0
  ) {
    return true;
  }

  if (
    !firebaseRefreshToken.isEmpty()
  ) {
    if (
      firebaseRefreshIdToken()
    ) {
      return true;
    }

    Serial.println(
      "[Firebase] Stored refresh token rejected."
    );
  }

  return firebaseSignIn();
}

// ----------------------------------------------------------------------------

static bool firebaseUploadLatest() {
  if (
    !FIREBASE_ENABLED
  ) {
    return true;
  }

  if (
    WiFi.status() != WL_CONNECTED
  ) {
    return false;
  }

  if (
    !firebaseEnsureAuthenticated()
  ) {
    return false;
  }

  const String url =
    firebaseDatabaseUrl() +
    "/devices/" +
    FIREBASE_DEVICE_ID +
    "/latest.json?auth=" +
    firebaseIdToken;

  const String payload =
    buildDashboardJson();

  WiFiClientSecure client;

  client.setCACert(
    FIREBASE_GTS_ROOT_R1
  );

  HTTPClient http;

  http.setConnectTimeout(
    FIREBASE_HTTP_TIMEOUT_MS
  );

  http.setTimeout(
    FIREBASE_HTTP_TIMEOUT_MS
  );

  if (
    !http.begin(
      client,
      url
    )
  ) {
    Serial.println(
      "[Firebase] Upload HTTPS begin failed."
    );

    return false;
  }

  http.addHeader(
    "Content-Type",
    "application/json"
  );

  const int code =
    http.PUT(
      payload
    );

  const String response =
    http.getString();

  http.end();

  if (
    code == 401 ||
    code == 403
  ) {
    Serial.printf(
      "[Firebase] Upload auth rejected: HTTP %d\n",
      code
    );

    firebaseAuthenticated =
      false;

    return false;
  }

  if (
    code < 200 ||
    code >= 300
  ) {
    Serial.printf(
      "[Firebase] Upload failed: HTTP %d\n",
      code
    );

    Serial.printf(
      "[Firebase] Upload Error: %s\n",
      HTTPClient::errorToString(code).c_str()
    );

    if (response.length()) {
      Serial.println(
        response
      );
    }

    return false;
  }

  Serial.printf(
    "[Firebase] Upload OK: %u bytes\n",
    static_cast<unsigned>(
      payload.length()
    )
  );

  return true;
}

// ----------------------------------------------------------------------------

static void initializeFirebase() {
  if (
    !FIREBASE_ENABLED
  ) {
    Serial.println(
      "[Firebase] Disabled."
    );

    return;
  }

  if (
    WiFi.status() != WL_CONNECTED
  ) {
    Serial.println(
      "[Firebase] Wi-Fi unavailable at startup."
    );

    return;
  }

  firebasePreferences.begin(
    "firebase",
    false
  );

  firebaseRefreshToken =
    firebasePreferences.getString(
      "refresh",
      ""
    );

  if (
    firebaseRefreshToken.length()
  ) {
    Serial.println(
      "[Firebase] Stored refresh token found."
    );
  }

  firebaseEnsureAuthenticated();

  if (
    firebaseAuthenticated
  ) {
    firebaseUploadLatest();
    lastFirebaseUploadMs =
      millis();
  }
}

// ----------------------------------------------------------------------------

static void maintainFirebase() {
  if (
    !FIREBASE_ENABLED
  ) {
    return;
  }

  if (
    WiFi.status() != WL_CONNECTED
  ) {
    return;
  }

  const uint32_t now =
    millis();

  if (
    static_cast<uint32_t>(
      now -
      lastFirebaseUploadMs
    ) <
    FIREBASE_UPLOAD_INTERVAL_MS
  ) {
    // Refresh the token when it is close to expiry even if an upload is not
    // due yet.
    if (
      firebaseAuthenticated &&
      static_cast<int32_t>(
        now -
        firebaseTokenExpiresAtMs
      ) < 0
    ) {
      return;
    }
  }

  if (
    !firebaseEnsureAuthenticated()
  ) {
    return;
  }

  if (
    static_cast<uint32_t>(
      now -
      lastFirebaseUploadMs
    ) >=
    FIREBASE_UPLOAD_INTERVAL_MS
  ) {
    if (
      firebaseUploadLatest()
    ) {
      lastFirebaseUploadMs =
        now;
    }
  }
}


// ============================================================================
// I2C
// ============================================================================

static bool isI2CDevicePresent(uint8_t address) {

  Wire.beginTransmission(address);

  const uint8_t error = Wire.endTransmission();

  return error == 0;
}

// ----------------------------------------------------------------------------

static void scanI2CBus() {

  Serial.println();
  Serial.println("------------------------------------------------");
  Serial.println("[I2C] BUS SCAN");
  Serial.println("------------------------------------------------");

  int count = 0;

  for (uint8_t address = 1; address < 127; ++address) {

    Wire.beginTransmission(address);

    const uint8_t error = Wire.endTransmission();

    if (error == 0) {

      Serial.printf(
        "[I2C] FOUND 0x%02X\n",
        address
      );

      count++;
    }

    delay(2);
  }

  Serial.printf(
    "[I2C] Devices found: %d\n",
    count
  );

  Serial.println("------------------------------------------------");
}

// ============================================================================
// WIFI
// ============================================================================

static bool connectWiFiWithTimeout() {

  if (WiFi.status() == WL_CONNECTED) {

    wifiConnected = true;

    return true;
  }

  WiFi.mode(WIFI_STA);

  WiFi.setSleep(false);

  Serial.println("[WiFi] Connecting...");

  WiFi.begin(
    WIFI_SSID,
    WIFI_PASSWORD
  );

  const uint32_t start = millis();

  while (
    WiFi.status() != WL_CONNECTED &&
    static_cast<uint32_t>(millis() - start) <
      WIFI_TIMEOUT_MS
  ) {

    Serial.print(".");

    delay(300);
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {

    wifiConnected = true;

    Serial.print("[WiFi] Connected. IP: ");
    Serial.println(WiFi.localIP());

    Serial.printf(
      "[WiFi] RSSI: %d dBm\n",
      WiFi.RSSI()
    );

    return true;
  }

  wifiConnected = false;

  Serial.println("[WiFi] Connection failed.");

  return false;
}

// ----------------------------------------------------------------------------

static void maintainWiFi() {

  if (WiFi.status() == WL_CONNECTED) {

    wifiConnected = true;

    return;
  }

  wifiConnected = false;

  const uint32_t now = millis();

  if (
    static_cast<uint32_t>(now - lastWifiRetryMs) >=
    WIFI_RETRY_INTERVAL_MS
  ) {

    lastWifiRetryMs = now;

    connectWiFiWithTimeout();
  }
}

// ============================================================================
// RTC
// ============================================================================

static bool rtcTimeIsValid(
  const DateTime& t
) {

  return (
    t.year() >= 2024 &&
    t.year() <= 2099 &&
    t.month() >= 1 &&
    t.month() <= 12 &&
    t.day() >= 1 &&
    t.day() <= 31 &&
    t.hour() <= 23 &&
    t.minute() <= 59 &&
    t.second() <= 59
  );
}

// ----------------------------------------------------------------------------

static bool syncRTCFromNTP() {

  if (!health.ds3231) {
    return false;
  }

  if (WiFi.status() != WL_CONNECTED) {
    return false;
  }

  Serial.println(
    "[RTC] Starting NTP synchronization..."
  );

  configTime(
    GMT_OFFSET_SECONDS,
    DAYLIGHT_OFFSET_SECONDS,
    NTP_SERVER
  );

  struct tm timeinfo;

  if (!getLocalTime(
        &timeinfo,
        5000
      )) {

    Serial.println(
      "[RTC] NTP synchronization FAILED."
    );

    return false;
  }

  DateTime ntpTime(
    timeinfo.tm_year + 1900,
    timeinfo.tm_mon + 1,
    timeinfo.tm_mday,
    timeinfo.tm_hour,
    timeinfo.tm_min,
    timeinfo.tm_sec
  );

  rtc.adjust(ntpTime);

  rtcNtpSynchronized = true;

  lastNtpSyncMs = millis();

  Serial.printf(
    "[RTC] NTP -> DS3231: "
    "%04d-%02d-%02d %02d:%02d:%02d\n",
    ntpTime.year(),
    ntpTime.month(),
    ntpTime.day(),
    ntpTime.hour(),
    ntpTime.minute(),
    ntpTime.second()
  );

  return true;
}

// ----------------------------------------------------------------------------

static void initializeRTC() {

  Serial.println();
  Serial.println("[RTC] INITIALIZING DS3231");

  if (!health.ds3231) {

    health.rtcValid = false;

    Serial.println(
      "[RTC] DS3231 NOT AVAILABLE."
    );

    return;
  }

  if (connectWiFiWithTimeout()) {

    syncRTCFromNTP();
  }

  DateTime now = rtc.now();

  if (
    !rtcNtpSynchronized &&
    (
      rtc.lostPower() ||
      !rtcTimeIsValid(now)
    )
  ) {

    Serial.println(
      "[RTC] RTC time invalid/lost power."
    );

    Serial.println(
      "[RTC] Using compile-time fallback."
    );

    rtc.adjust(
      DateTime(
        F(__DATE__),
        F(__TIME__)
      )
    );

    now = rtc.now();
  }

  health.rtcValid = rtcTimeIsValid(now);

  Serial.printf(
    "[RTC] Current time: "
    "%04d-%02d-%02d %02d:%02d:%02d\n",
    now.year(),
    now.month(),
    now.day(),
    now.hour(),
    now.minute(),
    now.second()
  );

  Serial.printf(
    "[RTC] Source: %s\n",
    rtcNtpSynchronized
      ? "NTP -> DS3231"
      : "DS3231"
  );
}

// ----------------------------------------------------------------------------

static void maintainRTC() {

  if (!health.ds3231) {

    health.rtcValid = false;

    return;
  }

  if (WiFi.status() != WL_CONNECTED) {

    return;
  }

  const uint32_t now = millis();

  if (
    static_cast<uint32_t>(
      now - lastNtpSyncMs
    ) >= NTP_RESYNC_INTERVAL_MS
  ) {

    syncRTCFromNTP();
  }
}

// ----------------------------------------------------------------------------

static void readRTC(
  SensorData& data
) {

  if (!health.ds3231) {

    health.rtcValid = false;

    data.rtcIso = "";
    data.rtcDisplay = "";

    return;
  }

  const DateTime now = rtc.now();

  if (!rtcTimeIsValid(now)) {

    health.rtcValid = false;

    data.rtcIso = "";
    data.rtcDisplay = "";

    return;
  }

  char iso[32];

  char display[32];

  snprintf(
    iso,
    sizeof(iso),
    "%04d-%02d-%02dT%02d:%02d:%02d",
    now.year(),
    now.month(),
    now.day(),
    now.hour(),
    now.minute(),
    now.second()
  );

  snprintf(
    display,
    sizeof(display),
    "%02d:%02d:%02d %02d/%02d/%04d",
    now.hour(),
    now.minute(),
    now.second(),
    now.day(),
    now.month(),
    now.year()
  );

  data.rtcIso = iso;

  data.rtcDisplay = display;

  health.rtcValid = true;
}

// ============================================================================
// ADC
// ============================================================================

static int readAdcAverage(
  int pin,
  int samples = 32
) {

  if (samples <= 0) {
    samples = 1;
  }

  uint32_t sum = 0;

  for (int i = 0; i < samples; ++i) {

    sum += analogRead(pin);

    delayMicroseconds(250);
  }

  return static_cast<int>(
    sum /
    static_cast<uint32_t>(samples)
  );
}

// ----------------------------------------------------------------------------

static float adcRawToVoltage(
  int raw
) {

  if (raw < 0) {
    return NAN;
  }

  return (
    static_cast<float>(raw) /
    4095.0f
  ) * 3.3f;
}

// ============================================================================
// AQI
// ============================================================================

static int interpolateAQI(
  float concentration,
  const float* concentrationLow,
  const float* concentrationHigh,
  const int* indexLow,
  const int* indexHigh,
  size_t count
) {

  for (size_t i = 0; i < count; ++i) {

    if (
      concentration >= concentrationLow[i] &&
      concentration <= concentrationHigh[i]
    ) {

      const float range =
        concentrationHigh[i] -
        concentrationLow[i];

      if (range <= 0.0f) {
        return -1;
      }

      const float slope =
        static_cast<float>(
          indexHigh[i] -
          indexLow[i]
        ) / range;

      return static_cast<int>(
        roundf(
          slope *
          (
            concentration -
            concentrationLow[i]
          ) +
          static_cast<float>(
            indexLow[i]
          )
        )
      );
    }
  }

  if (
    concentration >
    concentrationHigh[count - 1]
  ) {
    return 500;
  }

  return -1;
}

// ----------------------------------------------------------------------------

static int calculatePM25AQI(
  float pm25
) {

  pm25 =
    floorf(
      pm25 * 10.0f
    ) / 10.0f;

  static const float low[] = {
    0.0f,
    9.1f,
    35.5f,
    55.5f,
    125.5f,
    225.5f
  };

  static const float high[] = {
    9.0f,
    35.4f,
    55.4f,
    125.4f,
    225.4f,
    325.4f
  };

  static const int ilow[] = {
    0,
    51,
    101,
    151,
    201,
    301
  };

  static const int ihigh[] = {
    50,
    100,
    150,
    200,
    300,
    500
  };

  return interpolateAQI(
    pm25,
    low,
    high,
    ilow,
    ihigh,
    sizeof(low) / sizeof(low[0])
  );
}

// ----------------------------------------------------------------------------

static int calculatePM10AQI(
  float pm10
) {

  pm10 = floorf(pm10);

  static const float low[] = {
    0.0f,
    55.0f,
    155.0f,
    255.0f,
    355.0f,
    425.0f
  };

  static const float high[] = {
    54.0f,
    154.0f,
    254.0f,
    354.0f,
    424.0f,
    604.0f
  };

  static const int ilow[] = {
    0,
    51,
    101,
    151,
    201,
    301
  };

  static const int ihigh[] = {
    50,
    100,
    150,
    200,
    300,
    500
  };

  return interpolateAQI(
    pm10,
    low,
    high,
    ilow,
    ihigh,
    sizeof(low) / sizeof(low[0])
  );
}

// ----------------------------------------------------------------------------

static String aqiStatusText(
  int aqi
) {

  if (aqi < 0) {
    return "UNAVAILABLE";
  }

  if (aqi <= 50) {
    return "GOOD";
  }

  if (aqi <= 100) {
    return "MODERATE";
  }

  if (aqi <= 150) {
    return "UNHEALTHY FOR SENSITIVE GROUPS";
  }

  if (aqi <= 200) {
    return "UNHEALTHY";
  }

  if (aqi <= 300) {
    return "VERY UNHEALTHY";
  }

  return "HAZARDOUS";
}

// ============================================================================
// TDS / PH / RAIN
// ============================================================================

static float calculateTDS(
  float voltage,
  float temperatureC
) {

  if (!validFloat(voltage)) {
    return NAN;
  }

  const float temperature =
    validFloat(temperatureC)
      ? temperatureC
      : 25.0f;

  const float compensation =
    1.0f +
    0.02f *
    (
      temperature -
      25.0f
    );

  if (compensation <= 0.0f) {
    return NAN;
  }

  const float compensatedVoltage =
    voltage /
    compensation;

  const float tds =
    (
      133.42f *
      compensatedVoltage *
      compensatedVoltage *
      compensatedVoltage
      -
      255.86f *
      compensatedVoltage *
      compensatedVoltage
      +
      857.39f *
      compensatedVoltage
    )
    *
    0.5f
    *
    TDS_CALIBRATION_FACTOR;

  if (
    tds < 0.0f ||
    tds > 5000.0f
  ) {
    return NAN;
  }

  return tds;
}

// ----------------------------------------------------------------------------

static float calculatePH(
  float voltage
) {

  if (!validFloat(voltage)) {
    return NAN;
  }

  if (
    fabsf(PH_SLOPE_V_PER_PH) <
    0.001f
  ) {
    return NAN;
  }

  const float ph =
    7.0f +
    (
      (
        voltage -
        PH_VOLTAGE_AT_PH7
      ) /
      PH_SLOPE_V_PER_PH
    );

  if (
    ph < 0.0f ||
    ph > 14.0f
  ) {
    return NAN;
  }

  return ph;
}

// ----------------------------------------------------------------------------

static float calculateRainWetPercent(
  int raw
) {

  if (
    RAIN_ADC_DRY ==
    RAIN_ADC_WET
  ) {
    return NAN;
  }

  const float percentage =
    100.0f *
    static_cast<float>(
      RAIN_ADC_DRY -
      raw
    ) /
    static_cast<float>(
      RAIN_ADC_DRY -
      RAIN_ADC_WET
    );

  return constrain(
    percentage,
    0.0f,
    100.0f
  );
}

// ============================================================================
// MAX9814
// ============================================================================

static void sampleMAX9814(
  int& peakToPeak,
  float& relativePct
) {

  int minimum = 4095;

  int maximum = 0;

  const uint32_t start = millis();

  while (
    static_cast<uint32_t>(
      millis() - start
    ) < 50UL
  ) {

    const int sample =
      analogRead(SOUND_ADC_PIN);

    if (sample < minimum) {
      minimum = sample;
    }

    if (sample > maximum) {
      maximum = sample;
    }
  }

  peakToPeak =
    maximum -
    minimum;

  relativePct =
    constrain(
      (
        static_cast<float>(
          peakToPeak
        ) /
        4095.0f
      ) *
      100.0f,
      0.0f,
      100.0f
    );
}

// ============================================================================
// PMS7003
// ============================================================================

static bool readPMS7003(
  uint16_t& pm1,
  uint16_t& pm25,
  uint16_t& pm10
) {

  uint8_t frame[32];

  while (pmsSerial.available() > 0) {

    if (
      pmsSerial.peek() !=
      0x42
    ) {

      pmsSerial.read();

      continue;
    }

    if (
      pmsSerial.available() <
      32
    ) {

      return false;
    }

    size_t bytesRead =
      pmsSerial.readBytes(
        frame,
        sizeof(frame)
      );

    if (
      bytesRead !=
      sizeof(frame)
    ) {

      return false;
    }

    if (
      frame[0] != 0x42 ||
      frame[1] != 0x4D
    ) {

      continue;
    }

    const uint16_t frameLength =
      (
        static_cast<uint16_t>(
          frame[2]
        ) << 8
      ) |
      frame[3];

    if (
      frameLength !=
      28
    ) {

      continue;
    }

    uint16_t checksum = 0;

    for (int i = 0; i < 30; ++i) {

      checksum += frame[i];
    }

    const uint16_t receivedChecksum =
      (
        static_cast<uint16_t>(
          frame[30]
        ) << 8
      ) |
      frame[31];

    if (
      checksum !=
      receivedChecksum
    ) {

      continue;
    }

    const uint16_t readPM1 =
      (
        static_cast<uint16_t>(
          frame[10]
        ) << 8
      ) |
      frame[11];

    const uint16_t readPM25 =
      (
        static_cast<uint16_t>(
          frame[12]
        ) << 8
      ) |
      frame[13];

    const uint16_t readPM10 =
      (
        static_cast<uint16_t>(
          frame[14]
        ) << 8
      ) |
      frame[15];

    if (
      readPM1 > 5000 ||
      readPM25 > 5000 ||
      readPM10 > 5000
    ) {

      continue;
    }

    pm1 = readPM1;

    pm25 = readPM25;

    pm10 = readPM10;

    return true;
  }

  return false;
}

// ============================================================================
// MH-Z19C
// ============================================================================

static uint8_t calculateMHZ19Checksum(
  const uint8_t* frame
) {

  uint8_t sum = 0;

  for (int i = 1; i < 8; ++i) {

    sum += frame[i];
  }

  return static_cast<uint8_t>(
    0xFF -
    sum +
    1
  );
}

// ----------------------------------------------------------------------------

static bool readMHZ19C(
  int& co2ppm
) {

  const uint8_t command[9] = {

    0xFF,
    0x01,
    0x86,
    0x00,
    0x00,
    0x00,
    0x00,
    0x00,
    0x79
  };

  while (
    mhzSerial.available()
  ) {

    mhzSerial.read();
  }

  mhzSerial.write(
    command,
    sizeof(command)
  );

  mhzSerial.flush();

  uint8_t response[9];

  size_t received = 0;

  const uint32_t start = millis();

  while (
    static_cast<uint32_t>(
      millis() - start
    ) < 1000UL &&
    received < sizeof(response)
  ) {

    while (
      mhzSerial.available() &&
      received < sizeof(response)
    ) {

      response[received++] =
        static_cast<uint8_t>(
          mhzSerial.read()
        );
    }

    delay(2);
  }

  if (
    received !=
    sizeof(response)
  ) {

    return false;
  }

  if (
    response[0] != 0xFF ||
    response[1] != 0x86
  ) {

    return false;
  }

  if (
    calculateMHZ19Checksum(
      response
    ) != response[8]
  ) {

    return false;
  }

  const int value =
    static_cast<int>(
      response[2]
    ) *
    256 +
    static_cast<int>(
      response[3]
    );

  if (
    value < 250 ||
    value > 10000
  ) {

    return false;
  }

  co2ppm = value;

  return true;
}

// ============================================================================
// SENSOR INITIALIZATION
// ============================================================================

static void initializeSensors() {

  Serial.println();
  Serial.println("================================================");
  Serial.println("INITIALIZING SENSORS");
  Serial.println("================================================");

  // --------------------------------------------------------------------------
  // I2C
  // --------------------------------------------------------------------------

  Wire.begin(
    I2C_SDA_PIN,
    I2C_SCL_PIN
  );

  Wire.setClock(100000);

#if defined(ESP32)
  Wire.setTimeOut(50);
#endif

  delay(100);

  scanI2CBus();

  // --------------------------------------------------------------------------
  // SHT31
  // --------------------------------------------------------------------------

  if (
    isI2CDevicePresent(
      SHT31_ADDRESS
    )
  ) {

    health.sht31 =
      sht31.begin(
        SHT31_ADDRESS
      );
  }
  else {

    health.sht31 = false;
  }

  Serial.printf(
    "[TEST] SHT31    0x44: %s\n",
    health.sht31
      ? "PASS"
      : "FAIL"
  );

  // --------------------------------------------------------------------------
  // BME680
  // --------------------------------------------------------------------------

  health.bme680 = false;
  health.bme680Address = 0;

  if (
    isI2CDevicePresent(
      BME680_ADDRESS
    )
  ) {

    if (
      bme680.begin(
        BME680_ADDRESS
      )
    ) {

      health.bme680 = true;

      health.bme680Address =
        BME680_ADDRESS;
    }
  }

  if (health.bme680) {

    bme680.setTemperatureOversampling(
      BME680_OS_8X
    );

    bme680.setHumidityOversampling(
      BME680_OS_2X
    );

    bme680.setPressureOversampling(
      BME680_OS_4X
    );

    bme680.setIIRFilterSize(
      BME680_FILTER_SIZE_3
    );

    bme680.setGasHeater(
      320,
      150
    );
  }

  Serial.printf(
    "[TEST] BME680: %s",
    health.bme680
      ? "PASS"
      : "FAIL"
  );

  if (health.bme680) {

    Serial.printf(
      " @ 0x%02X",
      health.bme680Address
    );
  }

  Serial.println();

  // --------------------------------------------------------------------------
  // BMP280
  //
  // Only initialize it if the address is not already occupied by BME680.
  // --------------------------------------------------------------------------

  health.bmp280 = false;
  health.bmp280Address = 0;

  if (
    !health.bme680 ||
    health.bme680Address !=
      BMP280_I2C_ADDRESS
  ) {

    if (
      isI2CDevicePresent(
        BMP280_I2C_ADDRESS
      )
    ) {

      if (
        bmp280.begin(
          BMP280_I2C_ADDRESS
        )
      ) {

        health.bmp280 = true;

        health.bmp280Address =
          BMP280_I2C_ADDRESS;
      }
    }
  }

  if (health.bmp280) {

    bmp280.setSampling(
      Adafruit_BMP280::MODE_NORMAL,
      Adafruit_BMP280::SAMPLING_X2,
      Adafruit_BMP280::SAMPLING_X16,
      Adafruit_BMP280::FILTER_X16,
      Adafruit_BMP280::STANDBY_MS_500
    );
  }

  Serial.printf(
    "[TEST] BMP280: %s",
    health.bmp280
      ? "PASS"
      : "FAIL"
  );

  if (health.bmp280) {

    Serial.printf(
      " @ 0x%02X",
      health.bmp280Address
    );
  }

  Serial.println();

  // --------------------------------------------------------------------------
  // BH1750
  // --------------------------------------------------------------------------

  if (
    isI2CDevicePresent(
      BH1750_ADDRESS
    )
  ) {

    health.bh1750 =
      bh1750.begin(
        BH1750::CONTINUOUS_HIGH_RES_MODE,
        BH1750_ADDRESS,
        &Wire
      );
  }
  else {

    health.bh1750 = false;
  }

  Serial.printf(
    "[TEST] BH1750   0x23: %s\n",
    health.bh1750
      ? "PASS"
      : "FAIL"
  );

  // --------------------------------------------------------------------------
  // VEML6075
  // --------------------------------------------------------------------------

  if (
    isI2CDevicePresent(
      VEML6075_ADDRESS
    )
  ) {

    health.veml6075 =
      veml6075.begin(
        VEML6075_100MS,
        false,
        false,
        &Wire
      );

    if (health.veml6075) {

      veml6075.setIntegrationTime(
        VEML6075_100MS
      );

      veml6075.setHighDynamic(
        false
      );

      veml6075.setForcedMode(
        false
      );
    }
  }
  else {

    health.veml6075 = false;
  }

  Serial.printf(
    "[TEST] VEML6075 0x10: %s\n",
    health.veml6075
      ? "PASS"
      : "FAIL"
  );

  // --------------------------------------------------------------------------
  // DS3231
  // --------------------------------------------------------------------------

  if (
    isI2CDevicePresent(
      DS3231_ADDRESS
    )
  ) {

    health.ds3231 =
      rtc.begin();
  }
  else {

    health.ds3231 = false;
  }

  Serial.printf(
    "[TEST] DS3231   0x68: %s\n",
    health.ds3231
      ? "PASS"
      : "FAIL"
  );

  if (health.ds3231) {

    if (rtc.lostPower()) {

      Serial.println(
        "[WARN] DS3231 reports LOST POWER."
      );

      Serial.println(
        "[WARN] RTC will be synchronized from NTP when Wi-Fi is available."
      );
    }
    else {

      Serial.println(
        "[RTC] Backup power/status appears OK."
      );
    }
  }

  // --------------------------------------------------------------------------
  // UART
  // --------------------------------------------------------------------------

  pmsSerial.begin(
    9600,
    SERIAL_8N1,
    PMS7003_RX_PIN,
    PMS7003_TX_PIN
  );

  mhzSerial.begin(
    9600,
    SERIAL_8N1,
    MHZ19C_RX_PIN,
    MHZ19C_TX_PIN
  );

  // --------------------------------------------------------------------------
  // ADC
  // --------------------------------------------------------------------------

  analogReadResolution(12);

#if defined(ADC_11db)

  analogSetPinAttenuation(
    TDS_ADC_PIN,
    ADC_11db
  );

  analogSetPinAttenuation(
    PH_ADC_PIN,
    ADC_11db
  );

  analogSetPinAttenuation(
    RAIN_ADC_PIN,
    ADC_11db
  );

  analogSetPinAttenuation(
    SOUND_ADC_PIN,
    ADC_11db
  );

#endif

  Serial.println(
    "[ADC] ADC channels configured."
  );

  Serial.println(
    "================================================"
  );
}

// ============================================================================
// SENSOR ACQUISITION
// ============================================================================

static void acquireSensors() {

  SensorData next = workingData;

  // --------------------------------------------------------------------------
  // SHT31
  // --------------------------------------------------------------------------

  if (health.sht31) {

    const float temperature =
      sht31.readTemperature();

    const float humidity =
      sht31.readHumidity();

    if (
      validFloat(temperature) &&
      temperature >= -40.0f &&
      temperature <= 125.0f
    ) {

      next.temperatureC =
        temperature;
    }

    if (
      validFloat(humidity) &&
      humidity >= 0.0f &&
      humidity <= 100.0f
    ) {

      next.humidityPct =
        humidity;
    }
  }

  // --------------------------------------------------------------------------
  // BME680
  // --------------------------------------------------------------------------

  if (health.bme680) {

    if (
      bme680.performReading()
    ) {

      const float temperature =
        bme680.temperature;

      const float humidity =
        bme680.humidity;

      const float pressure =
        bme680.pressure /
        100.0f;

      const float gas =
        bme680.gas_resistance /
        1000.0f;

      // SHT31 remains primary temperature/humidity.
      if (
        !validFloat(
          next.temperatureC
        ) &&
        validFloat(
          temperature
        )
      ) {

        next.temperatureC =
          temperature;
      }

      if (
        !validFloat(
          next.humidityPct
        ) &&
        validFloat(
          humidity
        )
      ) {

        next.humidityPct =
          humidity;
      }

      if (
        validFloat(pressure) &&
        pressure > 300.0f &&
        pressure < 1200.0f
      ) {

        next.pressureHpa =
          pressure;
      }

      if (
        validFloat(gas) &&
        gas >= 0.0f
      ) {

        next.gasKOhm =
          gas;
      }
    }
  }

  // --------------------------------------------------------------------------
  // BMP280
  // --------------------------------------------------------------------------

  if (health.bmp280) {

    const float temperature =
      bmp280.readTemperature();

    const float pressure =
      bmp280.readPressure() /
      100.0f;

    if (
      !validFloat(
        next.temperatureC
      ) &&
      validFloat(temperature)
    ) {

      next.temperatureC =
        temperature;
    }

    if (
      validFloat(pressure) &&
      pressure > 300.0f &&
      pressure < 1200.0f
    ) {

      if (
        !validFloat(
          next.pressureHpa
        ) ||
        !health.bme680
      ) {

        next.pressureHpa =
          pressure;
      }
    }
  }

  // --------------------------------------------------------------------------
  // PMS7003
  // --------------------------------------------------------------------------

  uint16_t pm1 = 0;
  uint16_t pm25 = 0;
  uint16_t pm10 = 0;

  if (
    readPMS7003(
      pm1,
      pm25,
      pm10
    )
  ) {

    next.pm1 = pm1;
    next.pm25 = pm25;
    next.pm10 = pm10;

    next.pmValid = true;

    health.pms7003 = true;
  }

  // --------------------------------------------------------------------------
  // MH-Z19C
  // --------------------------------------------------------------------------

  int co2 = -1;

  if (
    readMHZ19C(co2)
  ) {

    next.co2ppm =
      co2;

    next.co2Valid =
      true;

    health.mhz19c =
      true;
  }

  // --------------------------------------------------------------------------
  // BH1750
  // --------------------------------------------------------------------------

  if (health.bh1750) {

    const float lux =
      bh1750.readLightLevel();

    if (
      validFloat(lux) &&
      lux >= 0.0f
    ) {

      next.lux =
        lux;
    }
  }

  // --------------------------------------------------------------------------
  // VEML6075
  // --------------------------------------------------------------------------

  if (health.veml6075) {

    const float uvi =
      veml6075.readUVI();

    if (
      validFloat(uvi) &&
      uvi >= 0.0f &&
      uvi < 30.0f
    ) {

      next.uvIndex =
        uvi;
    }
  }

  // --------------------------------------------------------------------------
  // TDS
  // --------------------------------------------------------------------------

  next.tdsRaw =
    readAdcAverage(
      TDS_ADC_PIN
    );

  next.tdsVoltage =
    adcRawToVoltage(
      next.tdsRaw
    );

  next.tdsPpm =
    calculateTDS(
      next.tdsVoltage,
      next.temperatureC
    );

  // --------------------------------------------------------------------------
  // ESTIMATED TOTAL HARDNESS
  // --------------------------------------------------------------------------
  //
  // This uses TDS as a proxy.
  // pH is NOT mathematically converted into hardness because
  // pH alone cannot determine calcium/magnesium concentration.
  //
  // Result is labelled as ESTIMATED hardness in the dashboard.
  //

  if (
    validFloat(next.tdsPpm) &&
    next.tdsPpm >= 0.0f &&
    next.tdsPpm <= 5000.0f
  ) {

    next.estimatedHardnessMgL =
      next.tdsPpm *
      HARDNESS_TDS_FACTOR;

    // Safety limit.
    if (
      next.estimatedHardnessMgL < 0.0f ||
      next.estimatedHardnessMgL > 5000.0f
    ) {
      next.estimatedHardnessMgL = NAN;
    }

  }
  else {

    next.estimatedHardnessMgL = NAN;
  }

  health.tds =
    (
      next.tdsRaw >= 0 &&
      validFloat(
        next.tdsVoltage
      )
    );

  // --------------------------------------------------------------------------
  // pH
  // --------------------------------------------------------------------------

  const int phRaw =
    readAdcAverage(
      PH_ADC_PIN,
      64
    );

  const float phVoltage =
    adcRawToVoltage(
      phRaw
    );

  const float calculatedPH =
    calculatePH(
      phVoltage
    );

  if (
    phRaw >= 0 &&
    validFloat(phVoltage) &&
    validFloat(calculatedPH) &&
    calculatedPH >= 0.0f &&
    calculatedPH <= 14.0f
  ) {

    // Valid new reading
    next.phRaw =
      phRaw;

    next.phVoltage =
      phVoltage;

    next.ph =
      calculatedPH;

    health.ph =
      true;
  }
  else {

    // Invalid reading:
    // KEEP the previous valid pH instead of displaying "—".

    Serial.println(
      "[pH] Invalid reading - keeping previous valid value."
    );

    health.ph =
      validFloat(
        next.ph
      );
  }

  // --------------------------------------------------------------------------
  // Rain
  // --------------------------------------------------------------------------

  next.rainRaw =
    readAdcAverage(
      RAIN_ADC_PIN
    );

  next.rainWetPct =
    calculateRainWetPercent(
      next.rainRaw
    );

  health.rain =
    (
      next.rainRaw >= 0 &&
      validFloat(
        next.rainWetPct
      )
    );

  // --------------------------------------------------------------------------
  // MAX9814
  // --------------------------------------------------------------------------

  sampleMAX9814(
    next.soundPeakToPeak,
    next.soundRelativePct
  );

  health.sound =
    (
      next.soundPeakToPeak >= 0 &&
      validFloat(
        next.soundRelativePct
      )
  );

  // --------------------------------------------------------------------------
  // RTC
  // --------------------------------------------------------------------------

  readRTC(next);

  // --------------------------------------------------------------------------
  // AQI
  // --------------------------------------------------------------------------

  if (next.pmValid) {

    const int aqi25 =
      calculatePM25AQI(
        static_cast<float>(
          next.pm25
        )
      );

    const int aqi10 =
      calculatePM10AQI(
        static_cast<float>(
          next.pm10
        )
      );

    next.aqi =
      max(
        aqi25,
        aqi10
      );

    next.aqiStatus =
      aqiStatusText(
        next.aqi
      );
  }
  else {

    next.aqi = -1;

    next.aqiStatus =
      "UNAVAILABLE";
  }

  next.sampleMillis =
    millis();

  workingData =
    next;

  // --------------------------------------------------------------------------
  // SERIAL DIAGNOSTICS
  // --------------------------------------------------------------------------

  Serial.println();
  Serial.println(
    "[DATA] SENSOR SAMPLE"
  );

  Serial.printf(
    "  SHT31        : %s\n",
    health.sht31
      ? "OK"
      : "FAIL"
  );

  Serial.printf(
    "  BME680       : %s @ 0x%02X\n",
    health.bme680
      ? "OK"
      : "FAIL",
    health.bme680Address
  );

  Serial.printf(
    "  BMP280       : %s @ 0x%02X\n",
    health.bmp280
      ? "OK"
      : "FAIL",
    health.bmp280Address
  );

  Serial.printf(
    "  BH1750       : %s\n",
    health.bh1750
      ? "OK"
      : "FAIL"
  );

  Serial.printf(
    "  VEML6075     : %s\n",
    health.veml6075
      ? "OK"
      : "FAIL"
  );

  Serial.printf(
    "  DS3231       : %s\n",
    health.ds3231
      ? "OK"
      : "FAIL"
  );

  Serial.printf(
    "  PMS7003      : %s\n",
    health.pms7003
      ? "OK"
      : "WAITING"
  );

  Serial.printf(
    "  MH-Z19C      : %s\n",
    health.mhz19c
      ? "OK"
      : "WAITING"
  );

  Serial.printf(
    "  TDS          : %s\n",
    health.tds
      ? "OK"
      : "FAIL"
  );

  Serial.printf(
    "  pH           : %s\n",
    health.ph
      ? "OK"
      : "FAIL"
  );

  Serial.printf(
    "  Rain         : %s\n",
    health.rain
      ? "OK"
      : "FAIL"
  );

  Serial.printf(
    "  Sound        : %s\n",
    health.sound
      ? "OK"
      : "FAIL"
  );

  Serial.printf(
    "  Temperature  : %s C\n",
    validFloat(
      next.temperatureC
    )
      ? String(
          next.temperatureC,
          2
        ).c_str()
      : "N/A"
  );

  Serial.printf(
    "  Humidity     : %s %%\n",
    validFloat(
      next.humidityPct
    )
      ? String(
          next.humidityPct,
          2
        ).c_str()
      : "N/A"
  );

  Serial.printf(
    "  Pressure     : %s hPa\n",
    validFloat(
      next.pressureHpa
    )
      ? String(
          next.pressureHpa,
          2
        ).c_str()
      : "N/A"
  );

  Serial.printf(
    "  Gas          : %s kOhm\n",
    validFloat(
      next.gasKOhm
    )
      ? String(
          next.gasKOhm,
          2
        ).c_str()
      : "N/A"
  );

  Serial.printf(
    "  PM1.0        : %u ug/m3\n",
    next.pm1
  );

  Serial.printf(
    "  PM2.5        : %u ug/m3 [%s]\n",
    next.pm25,
    next.pmValid
      ? "VALID"
      : "INVALID"
  );

  Serial.printf(
    "  PM10         : %u ug/m3\n",
    next.pm10
  );

  Serial.printf(
    "  CO2          : %d ppm [%s]\n",
    next.co2ppm,
    next.co2Valid
      ? "VALID"
      : "INVALID"
  );

  Serial.printf(
    "  Light        : %s lux\n",
    validFloat(
      next.lux
    )
      ? String(
          next.lux,
          1
        ).c_str()
      : "N/A"
  );

  Serial.printf(
    "  UV Index     : %s\n",
    validFloat(
      next.uvIndex
    )
      ? String(
          next.uvIndex,
          2
        ).c_str()
      : "N/A"
  );

  Serial.printf(
    "  TDS          : %s mg/L\n",
    validFloat(
      next.tdsPpm
    )
      ? String(
          next.tdsPpm,
          1
        ).c_str()
      : "N/A"
  );

  Serial.printf(
    "  pH           : %s\n",
    validFloat(
      next.ph
    )
      ? String(
          next.ph,
          2
        ).c_str()
      : "N/A"
  );

  Serial.printf(
    "  Rain         : %s %% wet\n",
    validFloat(
      next.rainWetPct
    )
      ? String(
          next.rainWetPct,
          1
        ).c_str()
      : "N/A"
  );

  Serial.printf(
    "  Sound P2P    : %d\n",
    next.soundPeakToPeak
  );

  Serial.printf(
    "  AQI          : %d (%s)\n",
    next.aqi,
    next.aqiStatus.c_str()
  );

  Serial.printf(
    "  RTC          : %s\n",
    next.rtcDisplay.length()
      ? next.rtcDisplay.c_str()
      : "N/A"
  );
}

// ============================================================================
// PUBLISH SNAPSHOT
// ============================================================================

static void publishSnapshot(
  bool force = false
) {

  const uint32_t intervalMs =
    DASHBOARD_UPDATE_INTERVAL_MINUTES *
    60UL *
    1000UL;

  const uint32_t now =
    millis();

  if (
    !force &&
    publishedReady &&
    static_cast<uint32_t>(
      now - lastPublishMs
    ) < intervalMs
  ) {

    return;
  }

  publishedData =
    workingData;

  publishedReady =
    true;

  lastPublishMs =
    now;

  Serial.printf(
    "[PUBLISH] Dashboard snapshot updated. "
    "Interval = %lu minute(s)\n",
    static_cast<unsigned long>(
      DASHBOARD_UPDATE_INTERVAL_MINUTES
    )
  );
}

// ============================================================================
// DASHBOARD JSON
// ============================================================================

static String buildDashboardJson() {

  const SensorData& data =
    publishedReady
      ? publishedData
      : workingData;

  const String updatedAt =
    data.rtcIso.length()
      ? data.rtcIso
      : "1970-01-01T00:00:00";

  const String airQuality =
    data.aqi >= 0
      ? data.aqiStatus +
        " (AQI " +
        String(data.aqi) +
        ")"
      : "UNAVAILABLE";

  String json;

  json.reserve(6500);

  json +=
    "{\"updatedAt\":\"";

  json +=
    jsonEscape(
      updatedAt
    );

  json +=
    "\",\"slides\":[";

  // --------------------------------------------------------------------------
  // Slide 1
  // --------------------------------------------------------------------------

  json +=
    "{\"title\":\"Clean Environment\",\"rows\":[";

  json +=
    makeRow(
      "Air Quality",
      airQuality
    );

  json += ",";

  json +=
    makeRow(
      "PM2.5",
      data.pmValid
        ? String(data.pm25) +
          " µg/m³"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "PM10",
      data.pmValid
        ? String(data.pm10) +
          " µg/m³"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "Temperature",
      validFloat(
        data.temperatureC
      )
        ? String(
            data.temperatureC,
            1
          ) + " °C"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "Humidity",
      validFloat(
        data.humidityPct
      )
        ? String(
            data.humidityPct,
            1
          ) + " %"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "Water TDS",
      validFloat(
        data.tdsPpm
      )
        ? String(
            data.tdsPpm,
            0
          ) + " mg/L"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "pH Level",
      validFloat(
        data.ph
      )
        ? String(
            data.ph,
            2
          )
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "Estimated Hardness",
      validFloat(
        workingData.estimatedHardnessMgL
      )
        ? String(
            workingData.estimatedHardnessMgL,
            0
          ) + " mg/L"
        : "—"
    );

  json +=
    "]},";

  // --------------------------------------------------------------------------
  // Slide 2
  // --------------------------------------------------------------------------

  json +=
    "{\"title\":\"Live Sensors\",\"rows\":[";

  json +=
    makeRow(
      "Pressure",
      validFloat(
        data.pressureHpa
      )
        ? String(
            data.pressureHpa,
            1
          ) + " hPa"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "CO2",
      data.co2Valid
        ? String(
            data.co2ppm
          ) + " ppm"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "Gas Resistance",
      validFloat(
        data.gasKOhm
      )
        ? String(
            data.gasKOhm,
            1
          ) + " kΩ"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "Light Level",
      validFloat(
        data.lux
      )
        ? String(
            data.lux,
            1
          ) + " lux"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "UV Index",
      validFloat(
        data.uvIndex
      )
        ? String(
            data.uvIndex,
            2
          )
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "Rain Sensor",
      validFloat(
        data.rainWetPct
      )
        ? String(
            data.rainWetPct,
            1
          ) + " % wet"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "Sound Level",
      validFloat(
        data.soundRelativePct
      )
        ? String(
            data.soundRelativePct,
            1
          ) + " % relative"
        : "—"
    );

  json += ",";

  json +=
    makeRow(
      "RTC Time",
      data.rtcDisplay.length()
        ? data.rtcDisplay
        : "RTC NOT SET"
    );

  json +=
    "]},";

  // --------------------------------------------------------------------------
  // Slide 3
  // --------------------------------------------------------------------------

  json +=
    "{\"title\":\"Green Environment\",\"rows\":[";

  json +=
    makeRow(
      "Trees",
      "—"
    );

  json += ",";

  json +=
    makeRow(
      "Green Area",
      "—"
    );

  json += ",";

  json +=
    makeRow(
      "New Trees",
      "—"
    );

  json +=
    "]},";

  // --------------------------------------------------------------------------
  // Slide 4
  // --------------------------------------------------------------------------

  json +=
    "{\"title\":\"Green Energy\",\"rows\":[";

  json +=
    makeRow(
      "Solar Today",
      "—"
    );

  json += ",";

  json +=
    makeRow(
      "Energy Generated Today",
      "—"
    );

  json += ",";

  json +=
    makeRow(
      "CO₂ Saved",
      "—"
    );

  json +=
    "]}";

  json +=
    "],";

  // --------------------------------------------------------------------------
  // Diagnostics
  // --------------------------------------------------------------------------

  json +=
    "\"diagnostics\":{";

  json +=
    "\"uptimeMs\":";

  json +=
    String(
      millis()
    );

  json += ",";

  json +=
    "\"dashboardIntervalMinutes\":";

  json +=
    String(
      DASHBOARD_UPDATE_INTERVAL_MINUTES
    );

  json += ",";

  json +=
    "\"sensorAcquisitionIntervalSeconds\":";

  json +=
    String(
      SENSOR_ACQUISITION_INTERVAL_SECONDS
    );

  json += ",";

  json +=
    "\"wifiConnected\":";

  json +=
    boolJson(
      WiFi.status() ==
      WL_CONNECTED
    );

  json += ",";

  json +=
    "\"wifiRssi\":";

  json +=
    String(
      WiFi.RSSI()
    );

  json += ",";

  json +=
    "\"freeHeap\":";

  json +=
    String(
      ESP.getFreeHeap()
    );

  json += ",";

  json +=
    "\"sensors\":{";

  json +=
    "\"sht31\":";

  json +=
    boolJson(
      health.sht31
    );

  json += ",";

  json +=
    "\"bme680\":";

  json +=
    boolJson(
      health.bme680
    );

  json += ",";

  json +=
    "\"bme680Address\":";

  json +=
    String(
      health.bme680Address
    );

  json += ",";

  json +=
    "\"bmp280\":";

  json +=
    boolJson(
      health.bmp280
    );

  json += ",";

  json +=
    "\"bmp280Address\":";

  json +=
    String(
      health.bmp280Address
    );

  json += ",";

  json +=
    "\"bh1750\":";

  json +=
    boolJson(
      health.bh1750
    );

  json += ",";

  json +=
    "\"veml6075\":";

  json +=
    boolJson(
      health.veml6075
    );

  json += ",";

  json +=
    "\"ds3231\":";

  json +=
    boolJson(
      health.ds3231
    );

  json += ",";

  json +=
    "\"rtcValid\":";

  json +=
    boolJson(
      health.rtcValid
    );

  json += ",";

  json +=
    "\"pms7003\":";

  json +=
    boolJson(
      health.pms7003
    );

  json += ",";

  json +=
    "\"mhz19c\":";

  json +=
    boolJson(
      health.mhz19c
    );

  json += ",";

  json +=
    "\"tds\":";

  json +=
    boolJson(
      health.tds
    );

  json += ",";

  json +=
    "\"ph\":";

  json +=
    boolJson(
      health.ph
    );

  json += ",";

  json +=
    "\"rain\":";

  json +=
    boolJson(
      health.rain
    );

  json += ",";

  json +=
    "\"sound\":";

  json +=
    boolJson(
      health.sound
    );

  json +=
    "},";

  // --------------------------------------------------------------------------
  // ADC diagnostics
  // --------------------------------------------------------------------------

  json +=
    "\"adc\":{";

  json +=
    "\"tdsRaw\":";

  json +=
    String(
      workingData.tdsRaw
    );

  json += ",";

  json +=
    "\"tdsVoltage\":";

  if (
    validFloat(
      workingData.tdsVoltage
    )
  ) {

    json +=
      String(
        workingData.tdsVoltage,
        3
      );
  }
  else {

    json +=
      "null";
  }

  json += ",";

  json +=
    "\"phRaw\":";

  json +=
    String(
      workingData.phRaw
    );

  json += ",";

  json +=
    "\"phVoltage\":";

  if (
    validFloat(
      workingData.phVoltage
    )
  ) {

    json +=
      String(
        workingData.phVoltage,
        3
      );
  }
  else {

    json +=
      "null";
  }

  json += ",";

  json +=
    "\"rainRaw\":";

  json +=
    String(
      workingData.rainRaw
    );

  json += ",";

  json +=
    "\"soundPeakToPeak\":";

  json +=
    String(
      workingData.soundPeakToPeak
    );

  json +=
    "}";

  json +=
    "}";

  json +=
    "}";

  return json;
}

// ============================================================================
// HTTP HEADERS
// ============================================================================

static void addNoCacheHeaders() {

  server.sendHeader(
    "Cache-Control",
    "no-store, no-cache, must-revalidate, max-age=0"
  );

  server.sendHeader(
    "Pragma",
    "no-cache"
  );

  server.sendHeader(
    "Expires",
    "0"
  );
}

// ============================================================================
// DASHBOARD
// ============================================================================

static void handleDashboard() {

  if (
    !LittleFS.exists(
      "/index.html"
    )
  ) {

    server.send(
      500,
      "text/plain; charset=utf-8",
      "ERROR: /index.html missing from ESP32 LittleFS"
    );

    return;
  }

  File file =
    LittleFS.open(
      "/index.html",
      "r"
    );

  if (!file) {

    server.send(
      500,
      "text/plain; charset=utf-8",
      "ERROR: could not open /index.html"
    );

    return;
  }

  addNoCacheHeaders();

  server.streamFile(
    file,
    "text/html; charset=utf-8"
  );

  file.close();
}

// ============================================================================
// API / SENSORS
// ============================================================================

static void handleSensorsAPI() {

  addNoCacheHeaders();

  server.send(
    200,
    "application/json; charset=utf-8",
    buildDashboardJson()
  );
}

// ============================================================================
// API / HEALTH
// ============================================================================

static void handleHealthAPI() {

  addNoCacheHeaders();

  String json;

  json.reserve(3000);

  json += "{";

  json +=
    "\"ok\":true,";

  json +=
    "\"ip\":\"";

  json +=
    WiFi.localIP().toString();

  json +=
    "\",";

  json +=
    "\"rssi\":";

  json +=
    String(
      WiFi.RSSI()
    );

  json += ",";

  json +=
    "\"freeHeap\":";

  json +=
    String(
      ESP.getFreeHeap()
    );

  json += ",";

  json +=
    "\"littlefs\":";

  json +=
    boolJson(
      LittleFS.exists(
        "/index.html"
      )
    );

  json += ",";

  json +=
    "\"publishedReady\":";

  json +=
    boolJson(
      publishedReady
    );

  json += ",";

  json +=
    "\"dashboardIntervalMinutes\":";

  json +=
    String(
      DASHBOARD_UPDATE_INTERVAL_MINUTES
    );

  json += ",";

  json +=
    "\"sensors\":{";

  json +=
    "\"sht31\":";

  json +=
    boolJson(
      health.sht31
    );

  json += ",";

  json +=
    "\"bme680\":";

  json +=
    boolJson(
      health.bme680
    );

  json += ",";

  json +=
    "\"bme680Address\":";

  json +=
    String(
      health.bme680Address
    );

  json += ",";

  json +=
    "\"bmp280\":";

  json +=
    boolJson(
      health.bmp280
    );

  json += ",";

  json +=
    "\"bmp280Address\":";

  json +=
    String(
      health.bmp280Address
    );

  json += ",";

  json +=
    "\"bh1750\":";

  json +=
    boolJson(
      health.bh1750
    );

  json += ",";

  json +=
    "\"veml6075\":";

  json +=
    boolJson(
      health.veml6075
    );

  json += ",";

  json +=
    "\"ds3231\":";

  json +=
    boolJson(
      health.ds3231
    );

  json += ",";

  json +=
    "\"rtcValid\":";

  json +=
    boolJson(
      health.rtcValid
    );

  json += ",";

  json +=
    "\"pms7003\":";

  json +=
    boolJson(
      health.pms7003
    );

  json += ",";

  json +=
    "\"mhz19c\":";

  json +=
    boolJson(
      health.mhz19c
    );

  json += ",";

  json +=
    "\"tds\":";

  json +=
    boolJson(
      health.tds
    );

  json += ",";

  json +=
    "\"ph\":";

  json +=
    boolJson(
      health.ph
    );

  json += ",";

  json +=
    "\"rain\":";

  json +=
    boolJson(
      health.rain
    );

  json += ",";

  json +=
    "\"sound\":";

  json +=
    boolJson(
      health.sound
    );

  json +=
    "}";

  json +=
    "}";

  server.send(
    200,
    "application/json; charset=utf-8",
    json
  );
}

// ============================================================================
// API / REFRESH
// ============================================================================

static void handleRefreshAPI() {

  acquireSensors();

  publishSnapshot(true);

  addNoCacheHeaders();

  server.send(
    200,
    "application/json; charset=utf-8",
    buildDashboardJson()
  );
}

// ============================================================================
// WEB SERVER
// ============================================================================

static void setupWebServer() {

  server.on(
    "/",
    HTTP_GET,
    handleDashboard
  );

  server.on(
    "/api/sensors",
    HTTP_GET,
    handleSensorsAPI
  );

  server.on(
    "/api/data",
    HTTP_GET,
    handleSensorsAPI
  );

  server.on(
    "/api/health",
    HTTP_GET,
    handleHealthAPI
  );

  server.on(
    "/api/refresh",
    HTTP_POST,
    handleRefreshAPI
  );

  // --------------------------------------------------------------------------
  // RFC image
  // --------------------------------------------------------------------------

  server.on(
    "/rfc1.jpeg",
    HTTP_GET,
    []() {

      if (
        !LittleFS.exists(
          "/rfc1.jpeg"
        )
      ) {

        server.send(
          404,
          "text/plain; charset=utf-8",
          "ERROR: /rfc1.jpeg missing from ESP32 LittleFS"
        );

        return;
      }

      File image =
        LittleFS.open(
          "/rfc1.jpeg",
          "r"
        );

      if (!image) {

        server.send(
          500,
          "text/plain; charset=utf-8",
          "ERROR: could not open /rfc1.jpeg"
        );

        return;
      }

      server.sendHeader(
        "Cache-Control",
        "public, max-age=86400, immutable"
      );

      server.streamFile(
        image,
        "image/jpeg"
      );

      image.close();
    }
  );

  // --------------------------------------------------------------------------
  // Favicon
  // --------------------------------------------------------------------------

  server.on(
    "/favicon.ico",
    HTTP_GET,
    []() {

      server.send(
        204
      );
    }
  );

  // --------------------------------------------------------------------------
  // Not found
  // --------------------------------------------------------------------------

  server.onNotFound(
    []() {

      server.send(
        404,
        "application/json; charset=utf-8",
        "{\"error\":\"not_found\"}"
      );
    }
  );

  server.begin();

  Serial.println(
    "[HTTP] Web server started."
  );
}

// ============================================================================
// STARTUP SELF TEST
// ============================================================================

static void startupSelfTest() {

  Serial.println();
  Serial.println("================================================");
  Serial.println("STARTUP SELF TEST");
  Serial.println("================================================");

  Serial.printf(
    "[TEST] LittleFS /index.html : %s\n",
    LittleFS.exists(
      "/index.html"
    )
      ? "PASS"
      : "FAIL"
  );

  Serial.printf(
    "[TEST] I2C SDA             : GPIO%d\n",
    I2C_SDA_PIN
  );

  Serial.printf(
    "[TEST] I2C SCL             : GPIO%d\n",
    I2C_SCL_PIN
  );

  Serial.printf(
    "[TEST] PMS7003 UART        : RX=%d TX=%d\n",
    PMS7003_RX_PIN,
    PMS7003_TX_PIN
  );

  Serial.printf(
    "[TEST] MH-Z19C UART        : RX=%d TX=%d\n",
    MHZ19C_RX_PIN,
    MHZ19C_TX_PIN
  );

  Serial.printf(
    "[TEST] TDS ADC             : GPIO%d\n",
    TDS_ADC_PIN
  );

  Serial.printf(
    "[TEST] pH ADC              : GPIO%d\n",
    PH_ADC_PIN
  );

  Serial.printf(
    "[TEST] Rain ADC            : GPIO%d\n",
    RAIN_ADC_PIN
  );

  Serial.printf(
    "[TEST] Sound ADC           : GPIO%d\n",
    SOUND_ADC_PIN
  );

  Serial.printf(
    "[TEST] Dashboard interval  : %lu minute(s)\n",
    static_cast<unsigned long>(
      DASHBOARD_UPDATE_INTERVAL_MINUTES
    )
  );

  Serial.printf(
    "[TEST] Sample interval     : %lu second(s)\n",
    static_cast<unsigned long>(
      SENSOR_ACQUISITION_INTERVAL_SECONDS
    )
  );

  Serial.println(
    "================================================"
  );
}

// ============================================================================
// SETUP
// ============================================================================

void setup() {

  Serial.begin(
    115200
  );

  delay(800);

  Serial.println();
  Serial.println("================================================");
  Serial.println("RFC ESP32 ENVIRONMENTAL DASHBOARD");
  Serial.println("PRODUCTION FIRMWARE");
  Serial.println("================================================");

  // --------------------------------------------------------------------------
  // LittleFS
  // --------------------------------------------------------------------------

  if (
    !LittleFS.begin(true)
  ) {

    Serial.println(
      "[FATAL] LittleFS mount failed."
    );
  }
  else {

    Serial.printf(
      "[FS] Total = %u bytes\n",
      static_cast<unsigned>(
        LittleFS.totalBytes()
      )
    );

    Serial.printf(
      "[FS] Used  = %u bytes\n",
      static_cast<unsigned>(
        LittleFS.usedBytes()
      )
    );

    Serial.printf(
      "[FS] /index.html = %s\n",
      LittleFS.exists(
        "/index.html"
      )
        ? "FOUND"
        : "MISSING"
    );
  }

  // --------------------------------------------------------------------------
  // Hardware
  // --------------------------------------------------------------------------

  initializeSensors();

  // IMPORTANT:
  // RTC is initialized ONLY ONCE.
  initializeRTC();

  // --------------------------------------------------------------------------
  // First acquisition
  // --------------------------------------------------------------------------

  acquireSensors();

  // Make the first sample immediately visible.
  publishSnapshot(true);

  lastAcquisitionMs =
    millis();

  // --------------------------------------------------------------------------
  // Web server
  // --------------------------------------------------------------------------

  setupWebServer();

  // Firebase authentication/upload is optional and must never block sensor operation.
  initializeFirebase();

  // --------------------------------------------------------------------------
  // Self test
  // --------------------------------------------------------------------------

  startupSelfTest();

  // --------------------------------------------------------------------------
  // Ready
  // --------------------------------------------------------------------------

  if (
    WiFi.status() ==
    WL_CONNECTED
  ) {

    const String ip =
      WiFi.localIP().toString();

    Serial.println();
    Serial.println("================================================");
    Serial.println("SYSTEM READY");
    Serial.printf(
      "Dashboard : http://%s/\n",
      ip.c_str()
    );

    Serial.printf(
      "Sensors   : http://%s/api/sensors\n",
      ip.c_str()
    );

    Serial.printf(
      "Health    : http://%s/api/health\n",
      ip.c_str()
    );

    Serial.printf(
      "Refresh   : POST http://%s/api/refresh\n",
      ip.c_str()
    );

    Serial.println("================================================");
  }
  else {

    Serial.println();
    Serial.println(
      "[WARN] Wi-Fi is not connected."
    );

    Serial.println(
      "[WARN] Sensor operation will continue."
    );

    Serial.println(
      "[WARN] Wi-Fi will be retried automatically."
    );
  }
}

// ============================================================================
// LOOP
// ============================================================================

void loop() {

  // --------------------------------------------------------------------------
  // HTTP
  // --------------------------------------------------------------------------

  server.handleClient();

  // --------------------------------------------------------------------------
  // Wi-Fi
  // --------------------------------------------------------------------------

  maintainWiFi();

  // --------------------------------------------------------------------------
  // RTC / NTP
  // --------------------------------------------------------------------------

  maintainRTC();

  // --------------------------------------------------------------------------
  // Sensor acquisition
  // --------------------------------------------------------------------------

  const uint32_t now =
    millis();

  if (
    static_cast<uint32_t>(
      now -
      lastAcquisitionMs
    ) >=
    SENSOR_ACQUISITION_INTERVAL_SECONDS *
    1000UL
  ) {

    lastAcquisitionMs =
      now;

    acquireSensors();
  }

  // --------------------------------------------------------------------------
  // Dashboard publishing
  // --------------------------------------------------------------------------

  publishSnapshot(false);

  // Firebase failures must never stop local sensor acquisition.
  maintainFirebase();

  delay(2);
}