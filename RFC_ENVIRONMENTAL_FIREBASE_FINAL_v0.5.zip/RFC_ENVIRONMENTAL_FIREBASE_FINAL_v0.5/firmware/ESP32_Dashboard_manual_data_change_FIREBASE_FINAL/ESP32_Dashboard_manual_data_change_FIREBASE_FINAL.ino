/*
===============================================================================
RFC ENVIRONMENTAL DASHBOARD
SECOND ESP32 OPERATOR CONTROLLER
ESP32 DEV MODULE + 20x4 I2C LCD + 4x4 KEYPAD
PRODUCTION-READY CONTROLLER FIRMWARE

Purpose
-------
This ESP32 is the dedicated operator controller for the six manually
maintained dashboard values:

  1. Current Solar Output       -> solarToday
  2. Energy Generated Today     -> energyToday
  3. CO2 Emissions Avoided     -> co2AvoidedToday
  4. Trees and Palms            -> trees
  5. Landscaped Green Area      -> greenArea
  6. New Plantation This Year  -> newTrees

Firebase path
-------------
/devices/rfc-environment-001/manual

The existing sensor ESP32 remains the owner of:
/devices/rfc-environment-001/latest

This controller never overwrites /latest.

Hardware
--------
LCD:
  SDA = GPIO21
  SCL = GPIO22
  I2C address = 0x27

4x4 keypad:
  R1 = GPIO32
  R2 = GPIO33
  R3 = GPIO25
  R4 = GPIO26
  C1 = GPIO27
  C2 = GPIO14
  C3 = GPIO13
  C4 = GPIO23

Keypad:
  1 2 3 A
  4 5 6 B
  7 8 9 C
  * 0 # D

Controls
--------
A = login/menu
B = home/back
C = refresh values from Firebase / clear while editing
D = status
# = confirm/save
* = cancel/back
A while editing a decimal value = decimal point

Required Arduino libraries
--------------------------
- LiquidCrystal_I2C
- Keypad
- WiFi
- HTTPClient
- WiFiClientSecure
- Preferences

Security
--------
1. Use a dedicated Firebase Email/Password account for this controller.
2. Replace all placeholders below before deployment.
3. The credentials supplied in the original source should be rotated if
   they were real production credentials, because they were exposed in
   source material.
4. Do not put the Firebase password in the dashboard HTML.

===============================================================================
*/

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Preferences.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Keypad.h>
#include <time.h>

// ============================================================================
// USER CONFIGURATION
// ============================================================================

// Wi-Fi
static const char* WIFI_SSID     = "YOUR_WIFI_SSID";
static const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// Firebase
static const bool FIREBASE_ENABLED = true;

static const char* FIREBASE_API_KEY =
  "YOUR_FIREBASE_WEB_API_KEY";

static const char* FIREBASE_DATABASE_URL =
  "https://YOUR_DATABASE.firebasedatabase.app";

static const char* FIREBASE_EMAIL =
  "YOUR_CONTROLLER_EMAIL";

static const char* FIREBASE_PASSWORD =
  "YOUR_CONTROLLER_PASSWORD";

static const char* FIREBASE_DEVICE_ID =
  "rfc-environment-001";

static const char* CONTROLLER_ID =
  "rfc-operator-001";

static const char* FIRMWARE_VERSION =
  "2.0.0";

// Firebase node containing the six editable values.
static const char* FIREBASE_MANUAL_PATH =
  "/devices/rfc-environment-001/manual";

// Time zone: India
static const char* NTP_SERVER = "pool.ntp.org";
static constexpr long GMT_OFFSET_SECONDS = 19800L;
static constexpr int DAYLIGHT_OFFSET_SECONDS = 0;


// Google Trust Services Root R1.
// Used for TLS certificate verification against Google Firebase endpoints.
// Replace/update this CA only if Google's certificate chain changes.
static const char FIREBASE_GTS_ROOT_R1[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
MIIFVzCCAz+gAwIBAgINAgPlk28xsBNJiGuiFzANBgkqhkiG9w0BAQwFADBHMQsw
CQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExMQzEU
MBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMTYwNjIyMDAwMDAwWhcNMzYwNjIyMDAw
MDAwWjBHMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZp
Y2VzIExMQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwggIiMA0GCSqGSIb3DQEBAQUA
A4ICDwAwggIKAoICAQC2EQKLHuOhd5s73L+UPreVp0A8of2C+X0yBoJx9vaMf/vo
27xqLpeXo4xL+Sv2sfnOhB2x+cWX3u+58qPpvBKJXqeqUqv4IyfLpLGcY9vXmX7w
Cl7raKb0xlpHDU0QM+NOsROjyBhsS+z8CZDfnWQpJSMHobTSPS5g4M/SCYe7zUjw
TcLCeoiKu7rPWRnWr4+wB7CeMfGCwcDfLqZtbBkOtdh+JhpFAz2weaSUKK0Pfybl
qAj+lug8aJRT7oM6iCsVlgmy4HqMLnXWnOunVmSPlk9orj2XwoSPwLxAwAtcvfaH
szVsrBhQf4TgTM2S0yDpM7xSma8ytSmzJSq0SPly4cpk9+aCEI3oncKKiPo4Zor8
Y/kB+Xj9e1x3+naH+uzfsQ55lVe0vSbv1gHR6xYKu44LtcXFilWr06zqkUspzBmk
MiVOKvFlRNACzqrOSbTqn3yDsEB750Orp2yjj32JgfpMpf/VjsPOS+C12LOORc92
wO1AK/1TD7Cn1TsNsYqiA94xrcx36m97PtbfkSIS5r762DL8EGMUUXLeXdYWk70p
aDPvOmbsB4om3xPXV2V4J95eSRQAogB/mqghtqmxlbCluQ0WEdrHbEg8QOB+DVrN
VjzRlwW5y0vtOUucxD/SVRNuJLDWcfr0wbrM7Rv1/oFB2ACYPTrIrnqYNxgFlQID
AQABo0IwQDAOBgNVHQ8BAf8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4E
FgQU5K8rJnEaK0gnhS9SZizv8IkTcT4wDQYJKoZIhvcNAQEMBQADggIBAJ+qQibb
C5u+/x6Wki4+omVKapi6Ist9wTrYggoGxval3sBOh2Z5ofmmWJyq+bXmYOfg6LEe
QkEzCzc9zolwFcq1JKjPa7XSQCGYzyI0zzvFIoTgxQ6KfF2I5DUkzps+GlQebtuy
h6f88/qBVRRiClmpIgUxPoLW7ttXNLwzldMXG+gnoot7TiYaelpkttGsN/H9oPM4
7HLwEXWdyzRSjeZ2axfG34arJ45JK3VmgRAhpuo+9K4l/3wV3s6MJT/KYnAK9y8J
ZgfIPxz88NtFMN9iiMG1D53Dn0reWVlHxYciNuaCp+0KueIHoI17eko8cdLiA6Ef
MgfdG+RCzgwARWGAtQsgWSl4vflVy2PFPEz0tv/bal8xa5meLMFrUKTX5hgUvYU/
Z6tGn6D/Qqc6f1zLXbBwHSs09dR2CQzreExZBfMzQsNhFRAbd03OIozUhfJFfbdT
6u9AWpQKXCBfTkBdYiJ23//OYb2MI3jSNwLgjt7RETeJ9r/tSQdirpLsQBqvFAnZ
0E6yove+7u7Y/9waLd64NnHi/Hm3lCXRSHNboTXns5lndcEZOitHTtNCjv0xyBZm
2tIMPNuzjsmhDYAPexZ3FL//2wmUspzO8IFgV6dtxQ/PeEMMA3KgqlbbC1j+Qa3bb
bP6MvPJwNQzcmRk13NfIRmPVnGuV/u3gm3c
-----END CERTIFICATE-----
)EOF";

// ============================================================================
// LCD
// ============================================================================

static constexpr uint8_t LCD_ADDRESS = 0x27;
static constexpr uint8_t LCD_COLUMNS = 20;
static constexpr uint8_t LCD_ROWS = 4;

LiquidCrystal_I2C lcd(
  LCD_ADDRESS,
  LCD_COLUMNS,
  LCD_ROWS
);

// ============================================================================
// KEYPAD
// ============================================================================

static constexpr byte KEYPAD_ROWS = 4;
static constexpr byte KEYPAD_COLS = 4;

char keypadKeys[KEYPAD_ROWS][KEYPAD_COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

byte keypadRowPins[KEYPAD_ROWS] = {
  32, 33, 25, 26
};

byte keypadColPins[KEYPAD_COLS] = {
  27, 14, 13, 23
};

Keypad keypad = Keypad(
  makeKeymap(keypadKeys),
  keypadRowPins,
  keypadColPins,
  KEYPAD_ROWS,
  KEYPAD_COLS
);

// ============================================================================
// LOCAL STORAGE
// ============================================================================

Preferences prefs;

// ============================================================================
// TIMING
// ============================================================================

static constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 15000UL;
static constexpr uint32_t WIFI_RETRY_INTERVAL_MS = 15000UL;
static constexpr uint32_t INPUT_TIMEOUT_MS = 60000UL;
static constexpr uint32_t MESSAGE_DELAY_MS = 1400UL;
static constexpr uint32_t FIREBASE_TIMEOUT_MS = 12000UL;

// ============================================================================
// DEFAULT VALUES
// ============================================================================
//
// These are commissioning defaults only.
// The first successful Firebase read replaces them.
// Change them to the actual current site values if required.
//

static constexpr float DEFAULT_SOLAR_KW = 3420.0f;
static constexpr float DEFAULT_ENERGY_KWH = 86400.0f;
static constexpr float DEFAULT_CO2_TONNES = 2.8f;
static constexpr long DEFAULT_TREES = 45280L;
static constexpr float DEFAULT_GREEN_AREA = 320.0f;
static constexpr long DEFAULT_NEW_TREES = 1250L;

// ============================================================================
// VALIDATION LIMITS
// ============================================================================

static constexpr float SOLAR_MIN = 0.0f;
static constexpr float SOLAR_MAX = 1000000.0f;

static constexpr float ENERGY_MIN = 0.0f;
static constexpr float ENERGY_MAX = 1000000000.0f;

static constexpr float CO2_MIN = 0.0f;
static constexpr float CO2_MAX = 1000000.0f;

static constexpr long TREES_MIN = 0L;
static constexpr long TREES_MAX = 10000000L;

static constexpr float GREEN_AREA_MIN = 0.0f;
static constexpr float GREEN_AREA_MAX = 100000000.0f;

static constexpr long NEW_TREES_MIN = 0L;
static constexpr long NEW_TREES_MAX = 10000000L;

// ============================================================================
// OPERATOR PIN
// ============================================================================
//
// CHANGE THIS before deployment.
//

static const char* OPERATOR_PIN = "2580";

// ============================================================================
// DATA
// ============================================================================

struct ManualValues {
  float solarToday;
  float energyToday;
  float co2AvoidedToday;
  long trees;
  float greenArea;
  long newTrees;
};

ManualValues values;

// ============================================================================
// FIREBASE AUTH STATE
// ============================================================================

String firebaseIdToken;
String firebaseRefreshToken;
String firebaseUid;

uint32_t firebaseTokenExpiresAt = 0;
uint32_t lastFirebaseAttempt = 0;

bool firebaseAuthenticated = false;

// ============================================================================
// FORWARD DECLARATIONS
// ============================================================================

void showHome();
void showMenu();
void showStatus();
bool verifyPin();
String readPin();
String readNumber(
  const char* title,
  const String& current,
  bool decimalAllowed
);

bool validNumber(
  const String& input,
  bool decimalAllowed
);

bool connectWiFi();
void maintainWiFi();

bool firebaseSignIn();
bool firebaseRefreshTokenNow();
bool firebaseEnsureAuthenticated();

bool firebaseGetManual();
bool firebaseSetManualValue(uint8_t index);
bool firebaseUpdateMetadata();

bool httpPostJson(
  const String& url,
  const String& body,
  String& response
);

bool httpPostForm(
  const String& url,
  const String& body,
  String& response
);

bool httpGet(
  const String& url,
  String& response,
  int& httpCode
);

bool httpPut(
  const String& url,
  const String& body,
  String& response,
  int& httpCode
);

bool extractJsonString(
  const String& json,
  const char* key,
  String& result
);

long extractJsonLong(
  const String& json,
  const char* key,
  long fallback
);

float extractJsonFloat(
  const String& json,
  const char* key,
  float fallback
);

String urlEncode(const String& input);
String jsonEscape(const String& input);

void loadLocalValues();
void saveLocalValues();
void initializeDefaults();

void editSolar();
void editEnergy();
void editCO2();
void editTrees();
void editGreenArea();
void editNewTrees();

void showMessage(
  const String& a,
  const String& b = "",
  const String& c = "",
  const String& d = ""
);

void validateConfiguration();

void printLine(uint8_t row, const String& text);
String clip20(const String& text);
String maskedPin(const String& pin);

bool valueInRange(
  float value,
  float minimum,
  float maximum
);

bool valueInRange(
  long value,
  long minimum,
  long maximum
);

void validateConfiguration() {

  bool ok = true;

  if (String(WIFI_SSID) == "YOUR_WIFI_SSID") {
    Serial.println("[CONFIG] Set WIFI_SSID before deployment.");
    ok = false;
  }

  if (String(WIFI_PASSWORD) == "YOUR_WIFI_PASSWORD") {
    Serial.println("[CONFIG] Set WIFI_PASSWORD before deployment.");
    ok = false;
  }

  if (String(FIREBASE_API_KEY) == "YOUR_FIREBASE_WEB_API_KEY") {
    Serial.println("[CONFIG] Set FIREBASE_API_KEY before deployment.");
    ok = false;
  }

  if (String(FIREBASE_DATABASE_URL).indexOf("YOUR_DATABASE") >= 0) {
    Serial.println("[CONFIG] Set FIREBASE_DATABASE_URL before deployment.");
    ok = false;
  }

  if (String(FIREBASE_EMAIL) == "YOUR_CONTROLLER_EMAIL") {
    Serial.println("[CONFIG] Set FIREBASE_EMAIL before deployment.");
    ok = false;
  }

  if (String(FIREBASE_PASSWORD) == "YOUR_CONTROLLER_PASSWORD") {
    Serial.println("[CONFIG] Set FIREBASE_PASSWORD before deployment.");
    ok = false;
  }

  if (String(OPERATOR_PIN) == "2580") {
    Serial.println("[CONFIG] WARNING: change default OPERATOR_PIN 2580.");
  }

  if (!ok) {
    Serial.println("[CONFIG] Placeholder credentials detected.");
    Serial.println("[CONFIG] Local operation is available; Firebase will not authenticate until configured.");
  }
}

// ============================================================================
// SETUP
// ============================================================================

void setup() {

  Serial.begin(115200);

  delay(500);

  Serial.println();
  Serial.println("==================================================");
  Serial.println("RFC OPERATOR CONTROLLER");
  Serial.println("PRODUCTION FIRMWARE");
  Serial.println("==================================================");
  Serial.print("Firmware: ");
  Serial.println(FIRMWARE_VERSION);
  Serial.print("Controller: ");
  Serial.println(CONTROLLER_ID);

  // --------------------------------------------------------------------------
  // I2C / LCD
  // --------------------------------------------------------------------------

  Wire.begin(21, 22);
  Wire.setClock(100000);

  lcd.begin();
  lcd.backlight();
  lcd.clear();

  // --------------------------------------------------------------------------
  // Preferences
  // --------------------------------------------------------------------------

  prefs.begin(
    "rfc-controller",
    false
  );

  initializeDefaults();
  loadLocalValues();

  showMessage(
    "RFC ENVIRONMENT",
    "OPERATOR CONTROLLER",
    "ESP32 DEV MODULE",
    "Starting..."
  );

  delay(1200);

  // --------------------------------------------------------------------------
  // Wi-Fi
  // --------------------------------------------------------------------------

  connectWiFi();

  // --------------------------------------------------------------------------
  // NTP
  // --------------------------------------------------------------------------

  if (
    WiFi.status() == WL_CONNECTED
  ) {
    configTime(
      GMT_OFFSET_SECONDS,
      DAYLIGHT_OFFSET_SECONDS,
      NTP_SERVER
    );
  }

  // --------------------------------------------------------------------------
  // Firebase
  // --------------------------------------------------------------------------

  if (
    FIREBASE_ENABLED &&
    WiFi.status() == WL_CONNECTED
  ) {

    showMessage(
      "FIREBASE",
      "Authenticating...",
      "",
      ""
    );

    if (
      firebaseEnsureAuthenticated()
    ) {

      Serial.println(
        "[Firebase] Authentication OK."
      );

      if (
        firebaseGetManual()
      ) {
        Serial.println(
          "[Firebase] Initial manual values loaded."
        );
      }
      else {
        Serial.println(
          "[Firebase] Initial manual read failed."
        );
      }

    }
    else {

      Serial.println(
        "[Firebase] Authentication failed."
      );

      showMessage(
        "FIREBASE OFFLINE",
        "Using local values",
        "",
        ""
      );

      delay(
        MESSAGE_DELAY_MS
      );
    }
  }

  showHome();

  Serial.println();
  Serial.println("SYSTEM READY");
  Serial.println("A = Menu");
  Serial.println("B = Home");
  Serial.println("C = Firebase Refresh");
  Serial.println("D = Status");
  Serial.println();
}

// ============================================================================
// LOOP
// ============================================================================

void loop() {

  maintainWiFi();

  char key = keypad.getKey();

  if (!key) {
    delay(2);
    return;
  }

  Serial.print("[KEY] ");
  Serial.println(key);

  // HOME
  if (key == 'A') {
    showMenu();
    return;
  }

  if (key == 'B') {
    showHome();
    return;
  }

  if (key == 'C') {

    showMessage(
      "REFRESHING",
      "Firebase values...",
      "",
      ""
    );

    if (
      firebaseGetManual()
    ) {

      showMessage(
        "REFRESH COMPLETE",
        "Values loaded",
        "",
        ""
      );

    }
    else {

      showMessage(
        "REFRESH FAILED",
        "Local values kept",
        "",
        ""
      );
    }

    delay(MESSAGE_DELAY_MS);

    showHome();

    return;
  }

  if (key == 'D') {
    showStatus();
    return;
  }
}

// ============================================================================
// DEFAULTS
// ============================================================================

void initializeDefaults() {

  values.solarToday =
    DEFAULT_SOLAR_KW;

  values.energyToday =
    DEFAULT_ENERGY_KWH;

  values.co2AvoidedToday =
    DEFAULT_CO2_TONNES;

  values.trees =
    DEFAULT_TREES;

  values.greenArea =
    DEFAULT_GREEN_AREA;

  values.newTrees =
    DEFAULT_NEW_TREES;
}

// ============================================================================
// LOCAL CACHE
// ============================================================================

void loadLocalValues() {

  values.solarToday =
    prefs.getFloat(
      "solar",
      values.solarToday
    );

  values.energyToday =
    prefs.getFloat(
      "energy",
      values.energyToday
    );

  values.co2AvoidedToday =
    prefs.getFloat(
      "co2",
      values.co2AvoidedToday
    );

  values.trees =
    prefs.getLong(
      "trees",
      values.trees
    );

  values.greenArea =
    prefs.getFloat(
      "green",
      values.greenArea
    );

  values.newTrees =
    prefs.getLong(
      "newtrees",
      values.newTrees
    );
}

// ----------------------------------------------------------------------------

void saveLocalValues() {

  prefs.putFloat(
    "solar",
    values.solarToday
  );

  prefs.putFloat(
    "energy",
    values.energyToday
  );

  prefs.putFloat(
    "co2",
    values.co2AvoidedToday
  );

  prefs.putLong(
    "trees",
    values.trees
  );

  prefs.putFloat(
    "green",
    values.greenArea
  );

  prefs.putLong(
    "newtrees",
    values.newTrees
  );
}

// ============================================================================
// WIFI
// ============================================================================

bool connectWiFi() {

  if (
    WiFi.status() == WL_CONNECTED
  ) {
    return true;
  }

  Serial.println(
    "[WiFi] Connecting..."
  );

  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.persistent(false);

  WiFi.begin(
    WIFI_SSID,
    WIFI_PASSWORD
  );

  const uint32_t start =
    millis();

  while (
    WiFi.status() != WL_CONNECTED &&
    (
      millis() - start
    ) < WIFI_CONNECT_TIMEOUT_MS
  ) {

    delay(250);

    Serial.print(".");
  }

  Serial.println();

  if (
    WiFi.status() ==
    WL_CONNECTED
  ) {

    Serial.print(
      "[WiFi] IP: "
    );

    Serial.println(
      WiFi.localIP()
    );

    Serial.print(
      "[WiFi] RSSI: "
    );

    Serial.print(
      WiFi.RSSI()
    );

    Serial.println(
      " dBm"
    );

    showMessage(
      "WIFI CONNECTED",
      WiFi.localIP().toString(),
      "RSSI " + String(WiFi.RSSI()) + " dBm",
      ""
    );

    delay(700);

    return true;
  }

  Serial.println(
    "[WiFi] Connection failed."
  );

  return false;
}

// ----------------------------------------------------------------------------

void maintainWiFi() {

  static uint32_t lastRetry = 0;

  if (
    WiFi.status() ==
    WL_CONNECTED
  ) {
    return;
  }

  if (
    millis() - lastRetry <
    WIFI_RETRY_INTERVAL_MS
  ) {
    return;
  }

  lastRetry =
    millis();

  connectWiFi();
}

// ============================================================================
// FIREBASE HTTP
// ============================================================================

bool httpPostJson(
  const String& url,
  const String& body,
  String& response
) {

  WiFiClientSecure client;

  client.setCACert(FIREBASE_GTS_ROOT_R1);

  HTTPClient http;

  http.setConnectTimeout(
    FIREBASE_TIMEOUT_MS
  );

  http.setTimeout(
    FIREBASE_TIMEOUT_MS
  );

  if (
    !http.begin(
      client,
      url
    )
  ) {
    return false;
  }

  http.addHeader(
    "Content-Type",
    "application/json"
  );

  const int code =
    http.POST(
      body
    );

  response =
    http.getString();

  http.end();

  return (
    code >= 200 &&
    code < 300
  );
}

// ----------------------------------------------------------------------------

bool httpPostForm(
  const String& url,
  const String& body,
  String& response
) {

  WiFiClientSecure client;

  client.setCACert(FIREBASE_GTS_ROOT_R1);

  HTTPClient http;

  http.setConnectTimeout(
    FIREBASE_TIMEOUT_MS
  );

  http.setTimeout(
    FIREBASE_TIMEOUT_MS
  );

  if (
    !http.begin(
      client,
      url
    )
  ) {
    return false;
  }

  http.addHeader(
    "Content-Type",
    "application/x-www-form-urlencoded"
  );

  const int code =
    http.POST(
      body
    );

  response =
    http.getString();

  http.end();

  return (
    code >= 200 &&
    code < 300
  );
}

// ----------------------------------------------------------------------------

bool httpGet(
  const String& url,
  String& response,
  int& httpCode
) {

  WiFiClientSecure client;

  client.setCACert(FIREBASE_GTS_ROOT_R1);

  HTTPClient http;

  http.setConnectTimeout(
    FIREBASE_TIMEOUT_MS
  );

  http.setTimeout(
    FIREBASE_TIMEOUT_MS
  );

  if (
    !http.begin(
      client,
      url
    )
  ) {
    httpCode = -1;
    return false;
  }

  http.addHeader(
    "Accept",
    "application/json"
  );

  httpCode =
    http.GET();

  response =
    http.getString();

  http.end();

  return (
    httpCode >= 200 &&
    httpCode < 300
  );
}

// ----------------------------------------------------------------------------

bool httpPut(
  const String& url,
  const String& body,
  String& response,
  int& httpCode
) {

  WiFiClientSecure client;

  client.setCACert(FIREBASE_GTS_ROOT_R1);

  HTTPClient http;

  http.setConnectTimeout(
    FIREBASE_TIMEOUT_MS
  );

  http.setTimeout(
    FIREBASE_TIMEOUT_MS
  );

  if (
    !http.begin(
      client,
      url
    )
  ) {
    httpCode = -1;
    return false;
  }

  http.addHeader(
    "Content-Type",
    "application/json"
  );

  httpCode =
    http.PUT(
      body
    );

  response =
    http.getString();

  http.end();

  return (
    httpCode >= 200 &&
    httpCode < 300
  );
}

// ============================================================================
// FIREBASE AUTHENTICATION
// ============================================================================

bool firebaseSignIn() {

  if (
    !FIREBASE_ENABLED ||
    WiFi.status() != WL_CONNECTED
  ) {
    return false;
  }

  String url =
    String(
      "https://identitytoolkit.googleapis.com/"
      "v1/accounts:signInWithPassword?key="
    ) +
    FIREBASE_API_KEY;

  String body =
    "{\"email\":\"" +
    jsonEscape(FIREBASE_EMAIL) +
    "\",\"password\":\"" +
    jsonEscape(FIREBASE_PASSWORD) +
    "\",\"returnSecureToken\":true}";

  String response;

  Serial.println(
    "[Firebase] Signing in..."
  );

  if (
    !httpPostJson(
      url,
      body,
      response
    )
  ) {

    Serial.println(
      "[Firebase] Sign-in failed."
    );

    Serial.println(
      response
    );

    firebaseAuthenticated =
      false;

    return false;
  }

  String idToken;
  String refreshToken;
  String uid;

  if (
    !extractJsonString(
      response,
      "idToken",
      idToken
    )
  ) {

    Serial.println(
      "[Firebase] idToken missing."
    );

    Serial.println(
      response
    );

    firebaseAuthenticated =
      false;

    return false;
  }

  extractJsonString(
    response,
    "refreshToken",
    refreshToken
  );

  extractJsonString(
    response,
    "localId",
    uid
  );

  const long expiresIn =
    extractJsonLong(
      response,
      "expiresIn",
      3600
    );

  firebaseIdToken =
    idToken;

  if (
    refreshToken.length()
  ) {
    firebaseRefreshToken =
      refreshToken;

    prefs.putString(
      "refresh",
      firebaseRefreshToken
    );
  }

  firebaseUid =
    uid;

  firebaseTokenExpiresAt =
    millis() +
    static_cast<uint32_t>(
      max(
        60L,
        expiresIn - 60L
      )
    ) *
    1000UL;

  firebaseAuthenticated =
    true;

  Serial.print(
    "[Firebase] Authenticated UID: "
  );

  Serial.println(
    firebaseUid
  );

  return true;
}

// ----------------------------------------------------------------------------

bool firebaseRefreshTokenNow() {

  if (
    !FIREBASE_ENABLED ||
    WiFi.status() != WL_CONNECTED ||
    firebaseRefreshToken.isEmpty()
  ) {
    return false;
  }

  String url =
    String(
      "https://securetoken.googleapis.com/"
      "v1/token?key="
    ) +
    FIREBASE_API_KEY;

  String body =
    "grant_type=refresh_token&refresh_token=" +
    urlEncode(
      firebaseRefreshToken
    );

  String response;

  if (
    !httpPostForm(
      url,
      body,
      response
    )
  ) {

    Serial.println(
      "[Firebase] Refresh failed."
    );

    firebaseAuthenticated =
      false;

    return false;
  }

  String idToken;
  String refreshToken;
  String uid;

  if (
    !extractJsonString(
      response,
      "id_token",
      idToken
    )
  ) {

    firebaseAuthenticated =
      false;

    return false;
  }

  extractJsonString(
    response,
    "refresh_token",
    refreshToken
  );

  extractJsonString(
    response,
    "user_id",
    uid
  );

  const long expiresIn =
    extractJsonLong(
      response,
      "expires_in",
      3600
    );

  firebaseIdToken =
    idToken;

  if (
    refreshToken.length()
  ) {

    firebaseRefreshToken =
      refreshToken;

    prefs.putString(
      "refresh",
      firebaseRefreshToken
    );
  }

  if (
    uid.length()
  ) {
    firebaseUid =
      uid;
  }

  firebaseTokenExpiresAt =
    millis() +
    static_cast<uint32_t>(
      max(
        60L,
        expiresIn - 60L
      )
    ) *
    1000UL;

  firebaseAuthenticated =
    true;

  Serial.println(
    "[Firebase] Token refreshed."
  );

  return true;
}

// ----------------------------------------------------------------------------

bool firebaseEnsureAuthenticated() {

  if (
    !FIREBASE_ENABLED ||
    WiFi.status() != WL_CONNECTED
  ) {
    return false;
  }

  if (
    firebaseAuthenticated &&
    static_cast<int32_t>(
      millis() -
      firebaseTokenExpiresAt
    ) < 0
  ) {
    return true;
  }

  if (
    firebaseRefreshToken.isEmpty()
  ) {

    firebaseRefreshToken =
      prefs.getString(
        "refresh",
        ""
      );
  }

  if (
    !firebaseRefreshToken.isEmpty()
  ) {

    if (
      firebaseRefreshTokenNow()
    ) {
      return true;
    }
  }

  return firebaseSignIn();
}

// ============================================================================
// FIREBASE GET SIX VALUES
// ============================================================================

bool firebaseGetManual() {

  if (
    !firebaseEnsureAuthenticated()
  ) {
    return false;
  }

  const String url =
    String(FIREBASE_DATABASE_URL) +
    FIREBASE_MANUAL_PATH +
    ".json?auth=" +
    firebaseIdToken;

  String response;
  int httpCode = 0;

  if (
    !httpGet(
      url,
      response,
      httpCode
    )
  ) {

    Serial.printf(
      "[Firebase] GET failed HTTP %d\n",
      httpCode
    );

    if (
      httpCode == 401 ||
      httpCode == 403
    ) {
      firebaseAuthenticated =
        false;
    }

    return false;
  }

  if (
    response == "null" ||
    response.length() < 2
  ) {

    Serial.println(
      "[Firebase] /manual is empty."
    );

    /*
       Keep local values if the node does not yet exist.
       The operator can save any value to create it.
    */

    return true;
  }

  ManualValues next =
    values;

  next.solarToday =
    extractJsonFloat(
      response,
      "solarToday",
      values.solarToday
    );

  next.energyToday =
    extractJsonFloat(
      response,
      "energyToday",
      values.energyToday
    );

  next.co2AvoidedToday =
    extractJsonFloat(
      response,
      "co2AvoidedToday",
      values.co2AvoidedToday
    );

  next.trees =
    extractJsonLong(
      response,
      "trees",
      values.trees
    );

  next.greenArea =
    extractJsonFloat(
      response,
      "greenArea",
      values.greenArea
    );

  next.newTrees =
    extractJsonLong(
      response,
      "newTrees",
      values.newTrees
    );

  // Validate before replacing live local values.
  if (
    !valueInRange(
      next.solarToday,
      SOLAR_MIN,
      SOLAR_MAX
    )
  ) {
    return false;
  }

  if (
    !valueInRange(
      next.energyToday,
      ENERGY_MIN,
      ENERGY_MAX
    )
  ) {
    return false;
  }

  if (
    !valueInRange(
      next.co2AvoidedToday,
      CO2_MIN,
      CO2_MAX
    )
  ) {
    return false;
  }

  if (
    !valueInRange(
      next.trees,
      TREES_MIN,
      TREES_MAX
    )
  ) {
    return false;
  }

  if (
    !valueInRange(
      next.greenArea,
      GREEN_AREA_MIN,
      GREEN_AREA_MAX
    )
  ) {
    return false;
  }

  if (
    !valueInRange(
      next.newTrees,
      NEW_TREES_MIN,
      NEW_TREES_MAX
    )
  ) {
    return false;
  }

  values =
    next;

  saveLocalValues();

  Serial.println(
    "[Firebase] Six manual values loaded."
  );

  return true;
}

// ============================================================================
// FIREBASE SET ONE VALUE
// ============================================================================

bool firebaseSetManualValue(
  uint8_t index
) {

  if (
    !firebaseEnsureAuthenticated()
  ) {
    return false;
  }

  String key;
  String valueJson;

  switch (index) {

    case 1:
      key = "solarToday";
      valueJson =
        String(values.solarToday, 2);
      break;

    case 2:
      key = "energyToday";
      valueJson =
        String(values.energyToday, 2);
      break;

    case 3:
      key = "co2AvoidedToday";
      valueJson =
        String(values.co2AvoidedToday, 2);
      break;

    case 4:
      key = "trees";
      valueJson =
        String(values.trees);
      break;

    case 5:
      key = "greenArea";
      valueJson =
        String(values.greenArea, 2);
      break;

    case 6:
      key = "newTrees";
      valueJson =
        String(values.newTrees);
      break;

    default:
      return false;
  }

  const String url =
    String(FIREBASE_DATABASE_URL) +
    FIREBASE_MANUAL_PATH +
    "/" +
    key +
    ".json?auth=" +
    firebaseIdToken;

  String response;
  int httpCode = 0;

  Serial.print(
    "[Firebase] SET "
  );

  Serial.print(
    key
  );

  Serial.print(
    " = "
  );

  Serial.println(
    valueJson
  );

  if (
    httpPut(
      url,
      valueJson,
      response,
      httpCode
    )
  ) {

    saveLocalValues();

    firebaseUpdateMetadata();

    Serial.println(
      "[Firebase] Value saved successfully."
    );

    return true;
  }

  Serial.printf(
    "[Firebase] SET failed HTTP %d\n",
    httpCode
  );

  if (
    response.length()
  ) {
    Serial.println(
      response
    );
  }

  if (
    httpCode == 401 ||
    httpCode == 403
  ) {
    firebaseAuthenticated =
      false;
  }

  return false;
}

// ============================================================================
// FIREBASE METADATA
// ============================================================================

bool firebaseUpdateMetadata() {

  if (
    !firebaseEnsureAuthenticated()
  ) {
    return false;
  }

  const String url =
    String(FIREBASE_DATABASE_URL) +
    FIREBASE_MANUAL_PATH +
    ".json?auth=" +
    firebaseIdToken;


  String response;
  int code = 0;

  // updatedAt
  String timestampUrl =
    String(FIREBASE_DATABASE_URL) +
    FIREBASE_MANUAL_PATH +
    "/updatedAt.json?auth=" +
    firebaseIdToken;

  if (
    !httpPut(
      timestampUrl,
      "{\".sv\":\"timestamp\"}",
      response,
      code
    )
  ) {
    return false;
  }

  // source
  String sourceUrl =
    String(FIREBASE_DATABASE_URL) +
    FIREBASE_MANUAL_PATH +
    "/source.json?auth=" +
    firebaseIdToken;

  if (
    !httpPut(
      sourceUrl,
      "\"operator-controller\"",
      response,
      code
    )
  ) {
    return false;
  }

  // controller
  String controllerUrl =
    String(FIREBASE_DATABASE_URL) +
    FIREBASE_MANUAL_PATH +
    "/controller.json?auth=" +
    firebaseIdToken;

  if (
    !httpPut(
      controllerUrl,
      "\"" +
      jsonEscape(CONTROLLER_ID) +
      "\"",
      response,
      code
    )
  ) {
    return false;
  }

  // firmware
  String firmwareUrl =
    String(FIREBASE_DATABASE_URL) +
    FIREBASE_MANUAL_PATH +
    "/firmware.json?auth=" +
    firebaseIdToken;

  if (
    !httpPut(
      firmwareUrl,
      "\"" +
      jsonEscape(FIRMWARE_VERSION) +
      "\"",
      response,
      code
    )
  ) {
    return false;
  }

  return true;
}

// ============================================================================
// PIN
// ============================================================================

bool verifyPin() {

  for (
    uint8_t attempt = 1;
    attempt <= 3;
    ++attempt
  ) {

    String entered =
      readPin();

    if (
      entered.isEmpty()
    ) {
      return false;
    }

    if (
      entered ==
      OPERATOR_PIN
    ) {

      showMessage(
        "ACCESS GRANTED",
        "",
        "",
        ""
      );

      delay(700);

      return true;
    }

    showMessage(
      "INVALID PIN",
      "Attempt " +
      String(attempt) +
      " / 3",
      "",
      ""
    );

    delay(900);
  }

  showMessage(
    "ACCESS DENIED",
    "Returning home",
    "",
    ""
  );

  delay(
    MESSAGE_DELAY_MS
  );

  return false;
}

// ----------------------------------------------------------------------------

String readPin() {

  String input;

  lcd.clear();

  printLine(
    0,
    "OPERATOR PIN"
  );

  printLine(
    1,
    "Enter PIN + #"
  );

  printLine(
    2,
    "PIN:"
  );

  printLine(
    3,
    "* Cancel"
  );

  const uint32_t start =
    millis();

  while (
    millis() - start <
    INPUT_TIMEOUT_MS
  ) {

    char key =
      keypad.getKey();

    if (!key) {
      delay(2);
      continue;
    }

    if (
      key == '*'
    ) {
      return "";
    }

    if (
      key == '#'
    ) {

      if (
        input.length() >= 4
      ) {
        return input;
      }

      continue;
    }

    if (
      key >= '0' &&
      key <= '9' &&
      input.length() < 8
    ) {

      input += key;

      printLine(
        2,
        "PIN:" +
        maskedPin(input)
      );
    }
  }

  return "";
}

// ============================================================================
// MAIN MENU
// ============================================================================

void showMenu() {

  if (
    !verifyPin()
  ) {
    showHome();
    return;
  }

  while (true) {

    lcd.clear();

    printLine(
      0,
      "1 Solar  2 Energy"
    );

    printLine(
      1,
      "3 CO2    4 Trees"
    );

    printLine(
      2,
      "5 Green  6 NewTree"
    );

    printLine(
      3,
      "D Status  * Exit"
    );

    const uint32_t start =
      millis();

    while (
      millis() - start <
      INPUT_TIMEOUT_MS
    ) {

      char key =
        keypad.getKey();

      if (!key) {
        delay(2);
        continue;
      }

      switch (key) {

        case '1':
          editSolar();
          break;

        case '2':
          editEnergy();
          break;

        case '3':
          editCO2();
          break;

        case '4':
          editTrees();
          break;

        case '5':
          editGreenArea();
          break;

        case '6':
          editNewTrees();
          break;

        case 'D':
          showStatus();
          break;

        case '*':
        case 'B':
          showHome();
          return;

        default:
          break;
      }

      break;
    }

    if (
      millis() - start >=
      INPUT_TIMEOUT_MS
    ) {

      showMessage(
        "MENU TIMEOUT",
        "",
        "",
        ""
      );

      delay(900);

      showHome();

      return;
    }
  }
}

// ============================================================================
// EDIT SOLAR
// ============================================================================

void editSolar() {

  String input =
    readNumber(
      "SOLAR OUTPUT kW",
      String(
        values.solarToday,
        2
      ),
      true
    );

  if (
    input.isEmpty()
  ) {
    return;
  }

  float newValue =
    input.toFloat();

  if (
    !valueInRange(
      newValue,
      SOLAR_MIN,
      SOLAR_MAX
    )
  ) {

    showMessage(
      "INVALID SOLAR",
      "Range 0-1000000",
      "kW",
      ""
    );

    delay(
      MESSAGE_DELAY_MS
    );

    return;
  }

  const float old =
    values.solarToday;

  values.solarToday =
    newValue;

  showMessage(
    "SAVING SOLAR...",
    String(newValue, 2) + " kW",
    "Firebase",
    ""
  );

  if (
    firebaseSetManualValue(1)
  ) {

    showMessage(
      "SOLAR UPDATED",
      String(newValue, 2) + " kW",
      "SAVE OK",
      ""
    );

  }
  else {

    values.solarToday =
      old;

    saveLocalValues();

    showMessage(
      "SAVE FAILED",
      "Solar unchanged",
      "Check Wi-Fi",
      ""
    );
  }

  delay(
    MESSAGE_DELAY_MS
  );
}

// ============================================================================
// EDIT ENERGY
// ============================================================================

void editEnergy() {

  String input =
    readNumber(
      "ENERGY TODAY kWh",
      String(
        values.energyToday,
        2
      ),
      true
    );

  if (
    input.isEmpty()
  ) {
    return;
  }

  float newValue =
    input.toFloat();

  if (
    !valueInRange(
      newValue,
      ENERGY_MIN,
      ENERGY_MAX
    )
  ) {

    showMessage(
      "INVALID ENERGY",
      "Value out of range",
      "kWh",
      ""
    );

    delay(
      MESSAGE_DELAY_MS
    );

    return;
  }

  const float old =
    values.energyToday;

  values.energyToday =
    newValue;

  showMessage(
    "SAVING ENERGY...",
    String(newValue, 2) + " kWh",
    "Firebase",
    ""
  );

  if (
    firebaseSetManualValue(2)
  ) {

    showMessage(
      "ENERGY UPDATED",
      String(newValue, 2) + " kWh",
      "SAVE OK",
      ""
    );

  }
  else {

    values.energyToday =
      old;

    saveLocalValues();

    showMessage(
      "SAVE FAILED",
      "Energy unchanged",
      "Check Wi-Fi",
      ""
    );
  }

  delay(
    MESSAGE_DELAY_MS
  );
}

// ============================================================================
// EDIT CO2
// ============================================================================

void editCO2() {

  String input =
    readNumber(
      "CO2 AVOIDED t",
      String(
        values.co2AvoidedToday,
        2
      ),
      true
    );

  if (
    input.isEmpty()
  ) {
    return;
  }

  float newValue =
    input.toFloat();

  if (
    !valueInRange(
      newValue,
      CO2_MIN,
      CO2_MAX
    )
  ) {

    showMessage(
      "INVALID CO2",
      "Value out of range",
      "tonnes",
      ""
    );

    delay(
      MESSAGE_DELAY_MS
    );

    return;
  }

  const float old =
    values.co2AvoidedToday;

  values.co2AvoidedToday =
    newValue;

  showMessage(
    "SAVING CO2...",
    String(newValue, 2) + " t",
    "Firebase",
    ""
  );

  if (
    firebaseSetManualValue(3)
  ) {

    showMessage(
      "CO2 UPDATED",
      String(newValue, 2) + " t",
      "SAVE OK",
      ""
    );

  }
  else {

    values.co2AvoidedToday =
      old;

    saveLocalValues();

    showMessage(
      "SAVE FAILED",
      "CO2 unchanged",
      "Check Wi-Fi",
      ""
    );
  }

  delay(
    MESSAGE_DELAY_MS
  );
}

// ============================================================================
// EDIT TREES
// ============================================================================

void editTrees() {

  String input =
    readNumber(
      "TREES & PALMS",
      String(
        values.trees
      ),
      false
    );

  if (
    input.isEmpty()
  ) {
    return;
  }

  long newValue =
    input.toInt();

  if (
    !valueInRange(
      newValue,
      TREES_MIN,
      TREES_MAX
    )
  ) {

    showMessage(
      "INVALID TREES",
      "Range 0-10000000",
      "Nos.",
      ""
    );

    delay(
      MESSAGE_DELAY_MS
    );

    return;
  }

  const long old =
    values.trees;

  values.trees =
    newValue;

  showMessage(
    "SAVING TREES...",
    String(newValue) + " Nos.",
    "Firebase",
    ""
  );

  if (
    firebaseSetManualValue(4)
  ) {

    showMessage(
      "TREES UPDATED",
      String(newValue) + " Nos.",
      "SAVE OK",
      ""
    );

  }
  else {

    values.trees =
      old;

    saveLocalValues();

    showMessage(
      "SAVE FAILED",
      "Trees unchanged",
      "Check Wi-Fi",
      ""
    );
  }

  delay(
    MESSAGE_DELAY_MS
  );
}

// ============================================================================
// EDIT GREEN AREA
// ============================================================================

void editGreenArea() {

  String input =
    readNumber(
      "GREEN AREA",
      String(
        values.greenArea,
        2
      ),
      true
    );

  if (
    input.isEmpty()
  ) {
    return;
  }

  float newValue =
    input.toFloat();

  if (
    !valueInRange(
      newValue,
      GREEN_AREA_MIN,
      GREEN_AREA_MAX
    )
  ) {

    showMessage(
      "INVALID AREA",
      "Value out of range",
      "acres",
      ""
    );

    delay(
      MESSAGE_DELAY_MS
    );

    return;
  }

  const float old =
    values.greenArea;

  values.greenArea =
    newValue;

  showMessage(
    "SAVING AREA...",
    String(newValue, 2) + " acres",
    "Firebase",
    ""
  );

  if (
    firebaseSetManualValue(5)
  ) {

    showMessage(
      "AREA UPDATED",
      String(newValue, 2) + " acres",
      "SAVE OK",
      ""
    );

  }
  else {

    values.greenArea =
      old;

    saveLocalValues();

    showMessage(
      "SAVE FAILED",
      "Area unchanged",
      "Check Wi-Fi",
      ""
    );
  }

  delay(
    MESSAGE_DELAY_MS
  );
}

// ============================================================================
// EDIT NEW TREES
// ============================================================================

void editNewTrees() {

  String input =
    readNumber(
      "NEW TREES",
      String(
        values.newTrees
      ),
      false
    );

  if (
    input.isEmpty()
  ) {
    return;
  }

  long newValue =
    input.toInt();

  if (
    !valueInRange(
      newValue,
      NEW_TREES_MIN,
      NEW_TREES_MAX
    )
  ) {

    showMessage(
      "INVALID NEW TREES",
      "Range 0-10000000",
      "Nos.",
      ""
    );

    delay(
      MESSAGE_DELAY_MS
    );

    return;
  }

  const long old =
    values.newTrees;

  values.newTrees =
    newValue;

  showMessage(
    "SAVING NEW TREES",
    String(newValue) + " Nos.",
    "Firebase",
    ""
  );

  if (
    firebaseSetManualValue(6)
  ) {

    showMessage(
      "NEW TREES UPDATED",
      String(newValue) + " Nos.",
      "SAVE OK",
      ""
    );

  }
  else {

    values.newTrees =
      old;

    saveLocalValues();

    showMessage(
      "SAVE FAILED",
      "New trees unchanged",
      "Check Wi-Fi",
      ""
    );
  }

  delay(
    MESSAGE_DELAY_MS
  );
}

// ============================================================================
// NUMBER INPUT
// ============================================================================

String readNumber(
  const char* title,
  const String& current,
  bool decimalAllowed
) {

  String input;

  lcd.clear();

  printLine(
    0,
    title
  );

  printLine(
    1,
    "Current:" + current
  );

  printLine(
    2,
    "New:"
  );

  if (
    decimalAllowed
  ) {
    printLine(
      3,
      "A=. #=Save *=Back"
    );
  }
  else {
    printLine(
      3,
      "#=Save *=Back C=Clear"
    );
  }

  const uint32_t start =
    millis();

  while (
    millis() - start <
    INPUT_TIMEOUT_MS
  ) {

    char key =
      keypad.getKey();

    if (!key) {
      delay(2);
      continue;
    }

    // CANCEL
    if (
      key == '*'
    ) {
      return "";
    }

    // SAVE
    if (
      key == '#'
    ) {

      if (
        validNumber(
          input,
          decimalAllowed
        )
      ) {
        return input;
      }

      showMessage(
        "INVALID NUMBER",
        "Enter a valid value",
        "",
        ""
      );

      delay(900);

      return "";
    }

    // CLEAR
    if (
      key == 'C'
    ) {

      input = "";

      printLine(
        2,
        "New:"
      );

      continue;
    }

    // DECIMAL
    if (
      key == 'A' &&
      decimalAllowed
    ) {

      if (
        input.indexOf('.') < 0
      ) {

        if (
          input.isEmpty()
        ) {
          input = "0";
        }

        input += '.';

        printLine(
          2,
          "New:" + input
        );
      }

      continue;
    }

    // DIGIT
    if (
      key >= '0' &&
      key <= '9'
    ) {

      if (
        input.length() >= 12
      ) {
        continue;
      }

      input += key;

      printLine(
        2,
        "New:" + input
      );
    }
  }

  showMessage(
    "INPUT TIMEOUT",
    "Nothing saved",
    "",
    ""
  );

  delay(900);

  return "";
}

// ----------------------------------------------------------------------------

bool validNumber(
  const String& input,
  bool decimalAllowed
) {

  if (
    input.isEmpty()
  ) {
    return false;
  }

  bool digitFound = false;
  bool decimalFound = false;

  for (
    uint16_t i = 0;
    i < input.length();
    ++i
  ) {

    char c =
      input[i];

    if (
      c >= '0' &&
      c <= '9'
    ) {

      digitFound = true;

      continue;
    }

    if (
      c == '.' &&
      decimalAllowed &&
      !decimalFound
    ) {

      decimalFound = true;

      continue;
    }

    return false;
  }

  return digitFound;
}

// ============================================================================
// HOME / STATUS
// ============================================================================

void showHome() {

  lcd.clear();

  printLine(
    0,
    "RFC OPERATOR"
  );

  printLine(
    1,
    "A MENU   B HOME"
  );

  printLine(
    2,
    "C SYNC   D STATUS"
  );

  if (
    WiFi.status() ==
    WL_CONNECTED
  ) {

    printLine(
      3,
      "WIFI OK"
    );

  }
  else {

    printLine(
      3,
      "WIFI OFFLINE"
    );
  }
}

// ----------------------------------------------------------------------------

void showStatus() {

  lcd.clear();

  printLine(
    0,
    "CONTROLLER STATUS"
  );

  if (
    WiFi.status() ==
    WL_CONNECTED
  ) {

    printLine(
      1,
      "WiFi OK " +
      String(WiFi.RSSI()) +
      "dBm"
    );

  }
  else {

    printLine(
      1,
      "WiFi OFFLINE"
    );
  }

  printLine(
    2,
    firebaseAuthenticated
      ? "Firebase ONLINE"
      : "Firebase OFFLINE"
  );

  printLine(
    3,
    "B Home  * Back"
  );

  while (true) {

    char key =
      keypad.getKey();

    if (
      key == 'B' ||
      key == '*' ||
      key == 'A'
    ) {

      showHome();

      return;
    }

    delay(2);
  }
}



// ============================================================================
// LCD
// ============================================================================

void showMessage(
  const String& a,
  const String& b,
  const String& c,
  const String& d
) {

  lcd.clear();

  printLine(0, a);
  printLine(1, b);
  printLine(2, c);
  printLine(3, d);
}

// ----------------------------------------------------------------------------

void printLine(
  uint8_t row,
  const String& text
) {

  if (
    row >= LCD_ROWS
  ) {
    return;
  }

  lcd.setCursor(
    0,
    row
  );

  lcd.print(
    "                    "
  );

  lcd.setCursor(
    0,
    row
  );

  lcd.print(
    clip20(text)
  );
}

// ----------------------------------------------------------------------------

String clip20(
  const String& text
) {

  if (
    text.length() <= 20
  ) {
    return text;
  }

  return text.substring(
    0,
    20
  );
}

// ----------------------------------------------------------------------------

String maskedPin(
  const String& pin
) {

  String result;

  for (
    uint16_t i = 0;
    i < pin.length();
    ++i
  ) {
    result += '*';
  }

  return result;
}

// ============================================================================
// VALIDATION
// ============================================================================

bool valueInRange(
  float value,
  float minimum,
  float maximum
) {

  return (
    isfinite(value) &&
    value >= minimum &&
    value <= maximum
  );
}

// ----------------------------------------------------------------------------

bool valueInRange(
  long value,
  long minimum,
  long maximum
) {

  return (
    value >= minimum &&
    value <= maximum
  );
}

// ============================================================================
// JSON HELPERS
// ============================================================================

String jsonEscape(
  const String& input
) {

  String output;

  output.reserve(
    input.length() + 8
  );

  for (
    uint16_t i = 0;
    i < input.length();
    ++i
  ) {

    char c =
      input[i];

    if (
      c == '\\'
    ) {
      output += "\\\\";
    }
    else if (
      c == '"'
    ) {
      output += "\\\"";
    }
    else if (
      c == '\n'
    ) {
      output += "\\n";
    }
    else if (
      c == '\r'
    ) {
      output += "\\r";
    }
    else {
      output += c;
    }
  }

  return output;
}

// ----------------------------------------------------------------------------

bool extractJsonString(
  const String& json,
  const char* key,
  String& result
) {

  const String needle =
    "\"" +
    String(key) +
    "\"";

  int pos =
    json.indexOf(
      needle
    );

  if (
    pos < 0
  ) {
    return false;
  }

  pos +=
    needle.length();

  while (
    pos < json.length() &&
    isspace(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    ++pos;
  }

  if (
    pos >= json.length() ||
    json[pos] != ':'
  ) {
    return false;
  }

  ++pos;

  while (
    pos < json.length() &&
    isspace(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    ++pos;
  }

  if (
    pos >= json.length() ||
    json[pos] != '"'
  ) {
    return false;
  }

  ++pos;

  String output;

  bool escaped = false;

  while (
    pos < json.length()
  ) {

    char c =
      json[pos++];

    if (
      escaped
    ) {

      if (c == 'n') output += '\n';
      else if (c == 'r') output += '\r';
      else if (c == 't') output += '\t';
      else output += c;

      escaped = false;

      continue;
    }

    if (
      c == '\\'
    ) {

      escaped = true;

      continue;
    }

    if (
      c == '"'
    ) {

      result =
        output;

      return true;
    }

    output += c;
  }

  return false;
}

// ----------------------------------------------------------------------------

long extractJsonLong(
  const String& json,
  const char* key,
  long fallback
) {

  const String needle =
    "\"" +
    String(key) +
    "\"";

  int pos =
    json.indexOf(
      needle
    );

  if (
    pos < 0
  ) {
    return fallback;
  }

  pos +=
    needle.length();

  while (
    pos < json.length() &&
    isspace(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    ++pos;
  }

  if (
    pos >= json.length() ||
    json[pos] != ':'
  ) {
    return fallback;
  }

  ++pos;

  while (
    pos < json.length() &&
    isspace(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    ++pos;
  }

  bool quoted = false;

  if (
    pos < json.length() &&
    json[pos] == '"'
  ) {

    quoted = true;
    ++pos;
  }

  bool negative = false;

  if (
    pos < json.length() &&
    json[pos] == '-'
  ) {

    negative = true;
    ++pos;
  }

  long result = 0;
  bool found = false;

  while (
    pos < json.length()
  ) {

    char c =
      json[pos];

    if (
      c < '0' ||
      c > '9'
    ) {
      break;
    }

    found = true;

    result =
      result * 10L +
      (
        c - '0'
      );

    ++pos;
  }

  if (
    !found
  ) {
    return fallback;
  }

  if (
    negative
  ) {
    result =
      -result;
  }

  if (
    quoted &&
    (
      pos >= json.length() ||
      json[pos] != '"'
    )
  ) {
    return fallback;
  }

  return result;
}

// ----------------------------------------------------------------------------

float extractJsonFloat(
  const String& json,
  const char* key,
  float fallback
) {

  const String needle =
    "\"" +
    String(key) +
    "\"";

  int pos =
    json.indexOf(
      needle
    );

  if (
    pos < 0
  ) {
    return fallback;
  }

  pos +=
    needle.length();

  while (
    pos < json.length() &&
    isspace(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    ++pos;
  }

  if (
    pos >= json.length() ||
    json[pos] != ':'
  ) {
    return fallback;
  }

  ++pos;

  while (
    pos < json.length() &&
    isspace(
      static_cast<unsigned char>(
        json[pos]
      )
    )
  ) {
    ++pos;
  }

  bool quoted = false;

  if (
    pos < json.length() &&
    json[pos] == '"'
  ) {

    quoted = true;
    ++pos;
  }

  const int start =
    pos;

  while (
    pos < json.length()
  ) {

    char c =
      json[pos];

    if (
      (
        c >= '0' &&
        c <= '9'
      ) ||
      c == '-' ||
      c == '+' ||
      c == '.' ||
      c == 'e' ||
      c == 'E'
    ) {

      ++pos;

      continue;
    }

    break;
  }

  if (
    pos <= start
  ) {
    return fallback;
  }

  String number =
    json.substring(
      start,
      pos
    );

  if (
    quoted &&
    (
      pos >= json.length() ||
      json[pos] != '"'
    )
  ) {
    return fallback;
  }

  float value =
    number.toFloat();

  if (
    !isfinite(value)
  ) {
    return fallback;
  }

  return value;
}

// ============================================================================
// URL ENCODING
// ============================================================================

String urlEncode(
  const String& input
) {

  const char hex[] =
    "0123456789ABCDEF";

  String output;

  for (
    uint16_t i = 0;
    i < input.length();
    ++i
  ) {

    uint8_t c =
      static_cast<uint8_t>(
        input[i]
      );

    if (
      (
        c >= 'a' &&
        c <= 'z'
      ) ||
      (
        c >= 'A' &&
        c <= 'Z'
      ) ||
      (
        c >= '0' &&
        c <= '9'
      ) ||
      c == '-' ||
      c == '_' ||
      c == '.' ||
      c == '~'
    ) {

      output +=
        static_cast<char>(c);

    }
    else {

      output += '%';

      output +=
        hex[
          (c >> 4) &
          0x0F
        ];

      output +=
        hex[
          c &
          0x0F
        ];
    }
  }

  return output;
}
