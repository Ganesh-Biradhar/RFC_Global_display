#include <Arduino.h>
#include <HardwareSerial.h>

/*
 * ================================================================
 *              PMS7003 ESP32 UART TEST
 * ================================================================
 *
 * ESP32 Dev Module
 *
 * PMS7003 UART:
 *
 * PMS TX  -> ESP32 GPIO16  (RX)
 * PMS RX  -> ESP32 GPIO17  (TX)
 *
 * PMS7003 CONTROL:
 *
 * PMS SET   -> ESP32 GPIO12
 * PMS RESET -> ESP32 GPIO25
 *
 * POWER:
 *
 * PMS VCC -> 5V
 * PMS GND -> ESP32 GND
 *
 * UART:
 *
 * 9600 baud
 * 8 data bits
 * No parity
 * 1 stop bit
 *
 * PMS7003 ACTIVE FRAME:
 *
 * 42 4D
 * 00 1C
 * 28 bytes of payload
 * checksum
 *
 * Total frame = 32 bytes
 *
 * ================================================================
 */


/* ================================================================
 * PIN CONFIGURATION
 * ================================================================
 */

constexpr int PMS_RX_PIN = 16;       // ESP32 RX <- PMS TX
constexpr int PMS_TX_PIN = 17;       // ESP32 TX -> PMS RX

constexpr int PMS_SET_PIN = 12;
constexpr int PMS_RESET_PIN = 25;


/* ================================================================
 * UART
 * ================================================================
 */

HardwareSerial pmsSerial(2);


/* ================================================================
 * PMS FRAME DEFINITIONS
 * ================================================================
 */

constexpr uint8_t PMS_HEADER_1 = 0x42;
constexpr uint8_t PMS_HEADER_2 = 0x4D;

constexpr uint8_t PMS_FRAME_SIZE = 32;

constexpr uint16_t PMS_EXPECTED_LENGTH = 28;


/*
 * Complete PMS frame.
 */
uint8_t frame[PMS_FRAME_SIZE];


/*
 * Number of bytes currently stored.
 */
uint8_t frameIndex = 0;


/* ================================================================
 * PARSER STATES
 * ================================================================
 */

enum class ParserState : uint8_t
{
  WAIT_HEADER_1,
  WAIT_HEADER_2,
  READ_FRAME
};

ParserState parserState =
  ParserState::WAIT_HEADER_1;


/* ================================================================
 * DIAGNOSTICS
 * ================================================================
 */

uint32_t bytesReceived = 0;

uint32_t validFrames = 0;

uint32_t invalidFrames = 0;

uint32_t headerErrors = 0;

uint32_t lengthErrors = 0;

uint32_t checksumErrors = 0;

uint32_t timeoutErrors = 0;


/*
 * Last time a valid frame was received.
 */
uint32_t lastValidFrameMs = 0;


/*
 * Last byte received.
 */
uint32_t lastByteMs = 0;


/*
 * Time when current frame started.
 */
uint32_t frameStartMs = 0;


/* ================================================================
 * TIMING
 * ================================================================
 */

constexpr uint32_t FRAME_TIMEOUT_MS = 100;


/*
 * Status interval.
 */
constexpr uint32_t STATUS_INTERVAL_MS = 5000;


/*
 * Sensor startup time.
 */
constexpr uint32_t SENSOR_STARTUP_DELAY_MS = 3000;


/* ================================================================
 * RAW FRAME DEBUG
 * ================================================================
 *
 * Set to true if you want every valid 32-byte frame printed.
 *
 * WARNING:
 * Printing every frame can slow down diagnostics.
 */

constexpr bool PRINT_RAW_VALID_FRAME = false;


/*
 * Set to true to print every byte received.
 *
 * Keep this FALSE for normal parser testing.
 *
 * Set TRUE only when debugging UART data.
 */

constexpr bool PRINT_EVERY_BYTE = false;


/* ================================================================
 * RESET PARSER
 * ================================================================
 */

void resetParser()
{
  parserState = ParserState::WAIT_HEADER_1;

  frameIndex = 0;

  frameStartMs = 0;
}


/* ================================================================
 * CLEAR UART BUFFER
 * ================================================================
 */

void clearPMSUART()
{
  while (pmsSerial.available() > 0)
  {
    pmsSerial.read();
  }
}


/* ================================================================
 * READ UINT16
 * ================================================================
 */

uint16_t readUint16(
  const uint8_t *buffer,
  uint8_t index
)
{
  return
    (
      (uint16_t)buffer[index] << 8
    )
    |
    buffer[index + 1];
}


/* ================================================================
 * CHECK PMS CHECKSUM
 * ================================================================
 *
 * PMS checksum:
 *
 * Sum bytes 0 through 29
 *
 * Compare against bytes 30 and 31.
 *
 * ================================================================
 */

bool checkChecksum()
{
  uint16_t calculatedChecksum = 0;

  for (
    uint8_t i = 0;
    i < 30;
    i++
  )
  {
    calculatedChecksum += frame[i];
  }


  uint16_t receivedChecksum =
    (
      (uint16_t)frame[30] << 8
    )
    |
    frame[31];


  return
    calculatedChecksum ==
    receivedChecksum;
}


/* ================================================================
 * PRINT RAW FRAME
 * ================================================================
 */

void printRawFrame()
{
  Serial.print("RAW FRAME: ");

  for (
    uint8_t i = 0;
    i < PMS_FRAME_SIZE;
    i++
  )
  {
    if (frame[i] < 0x10)
    {
      Serial.print('0');
    }

    Serial.print(
      frame[i],
      HEX
    );

    Serial.print(' ');
  }

  Serial.println();
}


/* ================================================================
 * PROCESS VALID FRAME
 * ================================================================
 */

void processValidFrame()
{
  /*
   * Standard atmospheric PM values:
   *
   * PM1.0  -> bytes 10-11
   * PM2.5  -> bytes 12-13
   * PM10   -> bytes 14-15
   */

  uint16_t pm1_0 =
    readUint16(frame, 10);

  uint16_t pm2_5 =
    readUint16(frame, 12);

  uint16_t pm10 =
    readUint16(frame, 14);


  /*
   * Count valid frame.
   */

  validFrames++;

  lastValidFrameMs = millis();


  /*
   * Print valid data.
   */

  Serial.println();
  Serial.println(
    "========================================"
  );

  Serial.println(
    "       PMS7003 VALID FRAME"
  );

  Serial.println(
    "========================================"
  );

  Serial.print(
    "PM1.0  : "
  );

  Serial.print(pm1_0);

  Serial.println(
    " ug/m3"
  );


  Serial.print(
    "PM2.5  : "
  );

  Serial.print(pm2_5);

  Serial.println(
    " ug/m3"
  );


  Serial.print(
    "PM10   : "
  );

  Serial.print(pm10);

  Serial.println(
    " ug/m3"
  );


  Serial.print(
    "Valid frames : "
  );

  Serial.println(validFrames);


  Serial.println(
    "========================================"
  );


  if (PRINT_RAW_VALID_FRAME)
  {
    printRawFrame();
  }
}


/* ================================================================
 * PROCESS COMPLETE FRAME
 * ================================================================
 */

void processFrame()
{
  /*
   * --------------------------------------------------------------
   * HEADER
   * --------------------------------------------------------------
   */

  if (
    frame[0] != PMS_HEADER_1 ||
    frame[1] != PMS_HEADER_2
  )
  {
    headerErrors++;
    invalidFrames++;

    return;
  }


  /*
   * --------------------------------------------------------------
   * LENGTH
   * --------------------------------------------------------------
   */

  uint16_t dataLength =
    readUint16(frame, 2);


  if (
    dataLength != PMS_EXPECTED_LENGTH
  )
  {
    lengthErrors++;
    invalidFrames++;

    Serial.print(
      "INVALID PMS FRAME LENGTH: "
    );

    Serial.println(
      dataLength
    );

    return;
  }


  /*
   * --------------------------------------------------------------
   * CHECKSUM
   * --------------------------------------------------------------
   */

  if (!checkChecksum())
  {
    checksumErrors++;
    invalidFrames++;

    Serial.println(
      "PMS CHECKSUM ERROR"
    );

    return;
  }


  /*
   * --------------------------------------------------------------
   * VALID FRAME
   * --------------------------------------------------------------
   */

  processValidFrame();
}


/* ================================================================
 * CHECK FRAME TIMEOUT
 * ================================================================
 *
 * IMPORTANT:
 *
 * This is checked independently from receiving a byte.
 *
 * The old code updated lastByteMs BEFORE checking the timeout,
 * making the timeout check ineffective.
 *
 * ================================================================
 */

void checkFrameTimeout()
{
  if (
    parserState != ParserState::READ_FRAME
  )
  {
    return;
  }


  uint32_t now = millis();


  if (
    (uint32_t)(now - lastByteMs)
    >
    FRAME_TIMEOUT_MS
  )
  {
    timeoutErrors++;
    invalidFrames++;

    resetParser();
  }
}


/* ================================================================
 * PROCESS PMS UART
 * ================================================================
 */

void processPMS()
{
  /*
   * First check whether a partially received frame has timed out.
   */

  checkFrameTimeout();


  /*
   * Process all available bytes.
   */

  while (
    pmsSerial.available() > 0
  )
  {
    uint8_t byte =
      (uint8_t)pmsSerial.read();


    uint32_t now =
      millis();


    bytesReceived++;

    lastByteMs = now;


    /*
     * Optional byte-level debugging.
     */

    if (PRINT_EVERY_BYTE)
    {
      if (byte < 0x10)
      {
        Serial.print('0');
      }

      Serial.print(
        byte,
        HEX
      );

      Serial.print(' ');
    }


    /* ============================================================
     * STATE 1
     *
     * Waiting for 0x42
     * ============================================================
     */

    if (
      parserState ==
      ParserState::WAIT_HEADER_1
    )
    {
      if (
        byte ==
        PMS_HEADER_1
      )
      {
        frame[0] =
          PMS_HEADER_1;

        frameIndex = 1;

        frameStartMs = now;

        parserState =
          ParserState::WAIT_HEADER_2;
      }

      continue;
    }


    /* ============================================================
     * STATE 2
     *
     * Waiting for 0x4D
     * ============================================================
     */

    if (
      parserState ==
      ParserState::WAIT_HEADER_2
    )
    {
      if (
        byte ==
        PMS_HEADER_2
      )
      {
        frame[1] =
          PMS_HEADER_2;

        frameIndex = 2;

        lastByteMs = now;

        parserState =
          ParserState::READ_FRAME;
      }
      else if (
        byte ==
        PMS_HEADER_1
      )
      {
        /*
         * We received another 0x42.
         *
         * Treat it as a new possible header.
         */

        headerErrors++;

        frame[0] =
          PMS_HEADER_1;

        frameIndex = 1;

        frameStartMs = now;

        parserState =
          ParserState::WAIT_HEADER_2;
      }
      else
      {
        headerErrors++;

        resetParser();
      }

      continue;
    }


    /* ============================================================
     * STATE 3
     *
     * Reading remaining frame bytes
     * ============================================================
     */

    if (
      parserState ==
      ParserState::READ_FRAME
    )
    {
      /*
       * Make sure we don't write outside frame[].
       */

      if (
        frameIndex >=
        PMS_FRAME_SIZE
      )
      {
        invalidFrames++;

        resetParser();

        continue;
      }


      /*
       * Store byte.
       */

      frame[frameIndex] =
        byte;

      frameIndex++;


      /*
       * Update byte timestamp.
       */

      lastByteMs = now;


      /*
       * Complete 32-byte frame.
       */

      if (
        frameIndex ==
        PMS_FRAME_SIZE
      )
      {
        processFrame();

        resetParser();
      }
    }
  }


  /*
   * Check again after processing the UART buffer.
   */

  checkFrameTimeout();
}


/* ================================================================
 * PRINT STATUS
 * ================================================================
 */

void printStatus()
{
  Serial.println();
  Serial.println(
    "----------------------------------------"
  );

  Serial.println(
    "          PMS7003 STATUS"
  );

  Serial.println(
    "----------------------------------------"
  );


  Serial.print(
    "Bytes received : "
  );

  Serial.println(
    bytesReceived
  );


  Serial.print(
    "Valid frames   : "
  );

  Serial.println(
    validFrames
  );


  Serial.print(
    "Invalid frames : "
  );

  Serial.println(
    invalidFrames
  );


  Serial.print(
    "Header errors  : "
  );

  Serial.println(
    headerErrors
  );


  Serial.print(
    "Length errors  : "
  );

  Serial.println(
    lengthErrors
  );


  Serial.print(
    "Checksum errors: "
  );

  Serial.println(
    checksumErrors
  );


  Serial.print(
    "Timeout errors : "
  );

  Serial.println(
    timeoutErrors
  );


  /*
   * Last valid frame age.
   */

  if (
    lastValidFrameMs != 0
  )
  {
    Serial.print(
      "Last valid age : "
    );

    Serial.print(
      millis() -
      lastValidFrameMs
    );

    Serial.println(
      " ms"
    );
  }
  else
  {
    Serial.println(
      "Last valid age : NEVER"
    );
  }


  /*
   * UART buffer status.
   */

  Serial.print(
    "UART buffer    : "
  );

  Serial.println(
    pmsSerial.available()
  );


  /*
   * Parser state.
   */

  Serial.print(
    "Parser state   : "
  );

  switch (parserState)
  {
    case ParserState::WAIT_HEADER_1:
      Serial.println(
        "WAIT_HEADER_1"
      );
      break;

    case ParserState::WAIT_HEADER_2:
      Serial.println(
        "WAIT_HEADER_2"
      );
      break;

    case ParserState::READ_FRAME:
      Serial.print(
        "READ_FRAME ("
      );

      Serial.print(
        frameIndex
      );

      Serial.println(
        "/32)"
      );

      break;
  }


  Serial.println(
    "----------------------------------------"
  );
}


/* ================================================================
 * SENSOR RESET
 * ================================================================
 */

void resetPMS()
{
  Serial.println();

  Serial.println(
    "Performing PMS7003 hardware reset..."
  );


  /*
   * RESET active LOW.
   */

  digitalWrite(
    PMS_RESET_PIN,
    LOW
  );


  delay(100);


  digitalWrite(
    PMS_RESET_PIN,
    HIGH
  );


  /*
   * Give sensor time to initialize.
   */

  Serial.println(
    "Waiting for PMS7003 startup..."
  );


  delay(
    SENSOR_STARTUP_DELAY_MS
  );


  /*
   * Remove any startup bytes that are not part of a
   * complete frame.
   */

  clearPMSUART();

  resetParser();


  Serial.println(
    "PMS7003 startup complete."
  );
}


/* ================================================================
 * SETUP
 * ================================================================
 */

void setup()
{
  /*
   * --------------------------------------------------------------
   * USB / DEBUG SERIAL
   * --------------------------------------------------------------
   */

  Serial.begin(
    115200
  );


  delay(1000);


  Serial.println();
  Serial.println(
    "========================================"
  );

  Serial.println(
    "       PMS7003 ESP32 TEST"
  );

  Serial.println(
    "========================================"
  );


  /*
   * --------------------------------------------------------------
   * PRINT CONNECTIONS
   * --------------------------------------------------------------
   */

  Serial.println(
    "Connections:"
  );

  Serial.println(
    "PMS TX    -> ESP32 GPIO16"
  );

  Serial.println(
    "PMS RX    -> ESP32 GPIO17"
  );

  Serial.println(
    "PMS SET   -> ESP32 GPIO12"
  );

  Serial.println(
    "PMS RESET -> ESP32 GPIO25"
  );

  Serial.println(
    "PMS GND   -> ESP32 GND"
  );

  Serial.println(
    "PMS VCC   -> 5V"
  );

  Serial.println();


  /*
   * --------------------------------------------------------------
   * CONTROL PINS
   * --------------------------------------------------------------
   */

  pinMode(
    PMS_SET_PIN,
    OUTPUT
  );

  pinMode(
    PMS_RESET_PIN,
    OUTPUT
  );


  /*
   * --------------------------------------------------------------
   * NORMAL ACTIVE STATE
   *
   * Based on the behavior you have been testing:
   *
   * SET   = HIGH
   * RESET = HIGH
   *
   * --------------------------------------------------------------
   */

  digitalWrite(
    PMS_SET_PIN,
    HIGH
  );

  digitalWrite(
    PMS_RESET_PIN,
    HIGH
  );


  /*
   * --------------------------------------------------------------
   * START PMS UART BEFORE RESET
   * --------------------------------------------------------------
   */

  Serial.println(
    "Starting PMS UART..."
  );


  pmsSerial.begin(
    9600,
    SERIAL_8N1,
    PMS_RX_PIN,
    PMS_TX_PIN
  );


  delay(100);


  /*
   * Clear any stale UART data.
   */

  clearPMSUART();


  /*
   * --------------------------------------------------------------
   * HARDWARE RESET
   * --------------------------------------------------------------
   */

  resetPMS();


  /*
   * --------------------------------------------------------------
   * FINAL STATUS
   * --------------------------------------------------------------
   */

  Serial.println();

  Serial.println(
    "========================================"
  );

  Serial.println(
    "PMS7003 UART READY"
  );

  Serial.println(
    "========================================"
  );

  Serial.println(
    "UART : 9600 8N1"
  );

  Serial.println(
    "RX   : GPIO16"
  );

  Serial.println(
    "TX   : GPIO17"
  );

  Serial.println();

  Serial.println(
    "Waiting for PMS7003 frames..."
  );

  Serial.println(
    "========================================"
  );
}


/* ================================================================
 * LOOP
 * ================================================================
 */

void loop()
{
  /*
   * PMS parser must run continuously.
   */

  processPMS();


  /*
   * Periodic status.
   */

  static uint32_t lastStatusMs = 0;

  uint32_t now = millis();


  if (
    (uint32_t)(now - lastStatusMs)
    >=
    STATUS_INTERVAL_MS
  )
  {
    lastStatusMs = now;

    printStatus();
  }


  /*
   * Small yield.
   */

  delay(1);
}